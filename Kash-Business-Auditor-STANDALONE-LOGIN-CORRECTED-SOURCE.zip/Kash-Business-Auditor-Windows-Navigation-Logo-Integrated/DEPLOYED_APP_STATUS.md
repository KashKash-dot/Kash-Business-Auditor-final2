# Deployment status

The previous Windows package loaded the hosted AppDeploy web URL. This source revision changes Electron to load a locally bundled UI and replaces the AppDeploy client import with a local-first adapter.

This revision has not yet been built and tested as a Windows installer in this environment. KMCC synchronization remains `NOT_CONFIGURED`; no production-ready shared backend is included. Refer to `STANDALONE_ARCHITECTURE.md` before using this build with real business data.
