# Kash Business Auditor — standalone desktop transition

## Changes in this revision
- Electron now loads the locally bundled Vite build from `dist/index.html`; it no longer opens the AppDeploy-hosted URL.
- The Vite build aliases the AppDeploy-injected browser client to `src/lib/local-client.ts`, allowing the desktop UI to compile without `@appdeploy/client`.
- The adapter stores records in the current Windows user's Chromium localStorage and implements the existing UI's main CRUD/login calls.
- The Windows build scripts now run Vite before Electron Builder and include `dist/**/*` in the packaged app.
- The existing `.ico` is still configured as the Windows executable/installer icon; the in-app logo is bundled from `public/resources` into `dist/resources`.
- The GitHub Actions workflow now runs the local build script and prefers the reviewed source ZIP filename.

## Important current limitations — do not treat as production-ready yet
- This is a standalone/local-first transition, not the completed secure shared-backend architecture. Local browser storage is not a tamper-proof database and should not be treated as the sole protection for sensitive business records.
- KMCC sync intentionally returns `NOT_CONFIGURED` until the actual KMCC sync API contract, endpoint and authentication method are known and tested. No sync key is embedded in the desktop app.
- The local adapter does not provide authoritative remote subscription enforcement, central trial enforcement, multi-computer data sharing, or a production payment/airtime provider integration. Airtime remains recorded as `Provider Not Connected`.
- Do not use this build for real payment processing or assume KMCC sync is working. The next required integration step is to connect to a verified KMCC endpoint using an authentication design that does not expose a shared secret in the client.

## Build
Run `npm install` then `npm run windows:build` on Windows or in the configured Windows GitHub Actions runner. The build should produce an NSIS installer and a portable EXE under `release/`.
