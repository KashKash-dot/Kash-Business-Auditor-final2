# Kash Business Auditor — Android wrapper build

This package intentionally does **not** compile the AppDeploy React source locally. AppDeploy injects `@appdeploy/client` and `@appdeploy/sdk` only in its own deployment environment, so a normal GitHub npm build cannot resolve those platform-provided modules.

The APK is an internet-only Capacitor native shell that loads the latest verified Kash Business Auditor AppDeploy deployment:
https://kash-business-auditor-b6wj6y.v2.appdeploy.ai/

This preserves the complete deployed Auditor application (Admin/attendant access, sales, barcode/item codes, multi-item receipts, stock, expenses, attendance, reports, subscription, Airtime page, branding, and backend data) while the APK provides the native installation icon and Android container.

The original full source ZIP remains separate and unchanged.
