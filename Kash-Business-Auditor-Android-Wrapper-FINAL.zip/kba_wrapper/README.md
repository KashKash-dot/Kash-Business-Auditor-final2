# Kash Business Auditor — Android Build Wrapper

## Why this wrapper exists
The full Kash Business Auditor source is an AppDeploy full-stack application. Its frontend imports `@appdeploy/client` and its backend imports `@appdeploy/sdk`. Those packages are platform-injected by AppDeploy and are intentionally not installed from npm, so GitHub Actions cannot compile the full source directly.

The deployed AppDeploy application is already in a clean `ready` state. This wrapper packages that verified live application inside a Capacitor Android shell. It is intentionally internet-only, matching the Auditor design.

## Important
Do not delete or replace the original source ZIP. This wrapper is a separate packaging layer for the APK.
