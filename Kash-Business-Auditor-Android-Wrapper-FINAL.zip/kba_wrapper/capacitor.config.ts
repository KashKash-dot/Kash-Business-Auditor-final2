import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.kashbusinessauditor.app',
  appName: 'Kash Business Auditor',
  webDir: 'dist',
  bundledWebRuntime: false,
  server: {
    androidScheme: 'https',
    url: 'https://kash-business-auditor-b6wj6y.v2.appdeploy.ai/',
    cleartext: false,
  },
};

export default config;
