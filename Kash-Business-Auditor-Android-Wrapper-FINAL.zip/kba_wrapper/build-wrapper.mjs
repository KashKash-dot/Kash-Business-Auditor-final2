import { mkdir, writeFile } from 'node:fs/promises';
await mkdir('dist', { recursive: true });
await writeFile('dist/index.html', `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#090909"><title>Kash Business Auditor</title></head><body style="margin:0;background:#090909"><div style="font-family:system-ui,sans-serif;color:#f5f0e4;padding:24px">Loading Kash Business Auditor…</div></body></html>`);
