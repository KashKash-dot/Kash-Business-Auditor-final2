# Kash Business Auditor

Android WebView wrapper for the Kash Business Auditor deployment.

## Android build

- Package: `com.kash.businessauditor`
- Minimum SDK: 23
- Target SDK: 35
- Compile SDK: 35
- Android Gradle Plugin: 8.6.1
- Gradle build in GitHub Actions: 8.7

The GitHub Actions workflow builds a debug APK and stores it as a workflow artifact.

## Build locally

Open this repository in Android Studio, or run `gradle assembleDebug` with a compatible Android SDK installed.
