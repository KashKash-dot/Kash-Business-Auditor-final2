package com.kash.businessauditor;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;

public class MainActivity extends Activity {
  private static final String URL = "https://kash-business-auditor-elninz.v2.appdeploy.ai/";
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    WebView w = new WebView(this);
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
    w.setWebViewClient(new WebViewClient());
    w.loadUrl(URL); setContentView(w);
  }
  @Override public void onBackPressed(){
    WebView w=(WebView)findViewById(android.R.id.content).getRootView().findFocus();
    super.onBackPressed();
  }
}
