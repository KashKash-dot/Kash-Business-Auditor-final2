# Kash Business Auditor — Definitive Final Source Package

This package is the finalized source baseline prepared from the V9 AppDeploy backup and the latest application requirements.

## Non-negotiable product rules

- The supplied gold-and-black Kash open-book logo is the official application identity.
- The Circle Style logo is used for authentication screens, navigation branding, and every in-app page header.
- The separate 3D golden open-book K icon is used for the installation/launcher icon, favicon, and PWA app icon.
- Every opened page keeps the same branded header and provides Go Back navigation where a previous in-app screen exists.
- The separate service-control application is not exposed as a page, menu item, settings section, or user-facing feature inside Kash Business Auditor.
- Background synchronization is handled through the hidden service-sync adapter. The Auditor stores business records under the authenticated business user and can push synchronization payloads to the configured service endpoint without exposing connection credentials in the UI.
- Admin and attendant authentication use server-side password/PIN hashing and expiring sessions.
- Admin sessions and attendant sessions are retained for the current browser session to reduce unexpected logout loops.

## Business capabilities

- 32-day free trial
- Business/company registration profile and generated business ID
- Admin owner details and ID/passport details
- Attendant registration, PINs, commission percentages, clock in/out
- Admin-only item/service code registration
- Barcode registration and barcode/code lookup with configured selling price
- Multi-item customer receipt/cart
- Discounts and VAT/tax calculation
- Cash, card and EFT payment recording
- Stock taking and inventory records
- Expenses
- Weekly/monthly reports
- Receipt centre and print workflow
- Admin correction/void authorization
- Currency configuration
- Subscription/payment records
- Wi-Fi/network awareness and Bluetooth-capable Android foundation
- Airtime module prepared for an approved provider/API
- Card-present payment adapter prepared for an approved terminal/provider

## Synchronization configuration

The source contains a backend service-sync adapter using the following server-side environment values:

- `KASH_SERVICE_SYNC_URL`
- `KASH_SERVICE_SYNC_KEY`

These values are intentionally not embedded in the app UI or source package. The live endpoint and key must be supplied securely when the separate service-control application is ready to accept the synchronization contract.

## Android build

The package includes Capacitor configuration and Android branding assets/templates. A full Android project should be generated with the normal Capacitor Android command before compiling the APK in an environment with the required npm/Android SDK dependencies.

This source ZIP is the definitive source package; it is not presented as a compiled APK.
