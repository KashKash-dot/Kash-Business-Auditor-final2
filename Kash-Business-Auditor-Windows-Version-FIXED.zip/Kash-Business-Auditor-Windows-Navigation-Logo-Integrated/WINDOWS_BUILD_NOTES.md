# Windows Build & Navigation Update

## Branding
- `public/resources/kash-business-auditor-circle-logo.png` is the in-app logo used on sign-in, header, and navigation.
- `public/resources/kash-business-auditor-install-icon.png` is the Windows/application installation icon artwork.
- `public/resources/kash-business-auditor-install-icon.ico` is the Windows `.ico` generated from the installation artwork.
- The browser manifest and page favicon use the installation artwork.

## Navigation
- Every signed-in page now has a visible Back button.
- Home returns to Dashboard.
- Header shortcuts provide quick access to Sales and Reports for Admin.
- Sidebar navigation remains available.
- Back navigation keeps a bounded history and falls back to Dashboard when there is no previous page.
- Buttons have keyboard focus styling and accessible labels/tooltips.

## Windows
The project now includes an Electron wrapper and Electron Builder configuration:
- `electron/main.cjs`
- `windows:build` -> web build + Windows NSIS installer + portable EXE
- `windows:pack` -> unpacked Windows application
- `.github/workflows/windows.yml` -> Windows GitHub Actions build from the project ZIP

The Windows build is x64 and produces both an installer and a portable `.exe`.

## Important
The Windows workflow intentionally starts from the uploaded source ZIP, extracts it, locates `package.json`, installs dependencies, builds the web app, and packages it as a Windows application. This keeps the ZIP-based GitHub workflow compatible with the current working method.

## Windows packaging model
The Windows build is an online desktop client that opens the deployed Kash Business Auditor web application in a hardened Electron window. This is intentional because the AppDeploy client/authentication layer is platform-injected in the web build and the Auditor is designed as internet-only. The Windows installer and portable EXE therefore use the same live business application and current navigation/branding rather than creating a separate offline copy.


## Build-failure correction (October 2026)

The Windows workflow packages the Electron online client only. It must NOT run `npm run build` / Vite because `src/App.tsx` imports the AppDeploy-provided `@appdeploy/client` module, which is not part of this ZIP's public npm dependencies. The Electron shell opens the deployed Auditor web app directly, so compiling the web source is unnecessary for this Windows wrapper.

The workflow therefore invokes `npx electron-builder --win nsis portable` directly and uses the specifically named `Kash-Business-Auditor-Windows-Version.zip` from the repository root. Keep that exact ZIP filename in GitHub and replace any older copy before running the workflow.
