# Kash Business Auditor — Definitive Final Package Manifest

## Package identity

- Product: Kash Business Auditor
- Package: Definitive Final Source Baseline
- Baseline: V9 AppDeploy backup, finalized for the current requirements
- In-app branding asset: `public/resources/kash-business-auditor-circle-logo.png`
- Installation/launcher branding asset: `public/resources/kash-business-auditor-install-icon.png`

## Finalized changes

- Circle Style gold-and-black Kash logo used throughout authentication, navigation and in-app page headers.
- 3D golden open-book K icon used for favicon, PWA/app installation and Android launcher branding.
- Persistent branded header on all authenticated application pages and opened sub-pages.
- Go Back navigation retained across in-app navigation.
- Admin/attendant login and password/PIN session handling retained and hardened against avoidable session-loss loops.
- User-facing service-control application references removed from Auditor navigation and settings.
- Hidden server-side service synchronization adapter added so the Auditor can synchronize business authorization/subscription state without exposing connection credentials in the UI.
- Barcode/item-code registration and configured-price lookup retained.
- Multi-item receipts, VAT, discounts, stock, expenses, attendance, commissions, reports, receipts and subscription records retained.
- Android/Capacitor configuration and branding assets retained for final APK generation.

## Important build note

This ZIP is the definitive **source** package. It is not a compiled APK. Generate the Android project/build in an environment with npm dependencies and the Android SDK installed, then compile and test the APK before distribution.
