import { createHash } from 'node:crypto';

export type ServiceSyncPayload = {
  businessId: string;
  businessName: string;
  status: string;
  subscriptionPlan: string;
  trialStart: string;
  trialDays: number;
};

export type ServiceSyncResult = {
  state: 'SYNCED' | 'PENDING' | 'FAILED' | 'NOT_CONFIGURED';
  lastSyncAt?: string;
  message?: string;
};

export function serviceSyncFingerprint(payload: ServiceSyncPayload): string {
  return createHash('sha256')
    .update(JSON.stringify(payload))
    .digest('hex');
}

export async function pushServiceSync(
  payload: ServiceSyncPayload,
  endpoint: string,
  registrationKey: string,
): Promise<ServiceSyncResult> {
  if (!endpoint || !registrationKey) {
    return { state: 'NOT_CONFIGURED', message: 'Synchronization endpoint is not configured.' };
  }

  try {
    const response = await fetch(endpoint.replace(/\/$/, '') + '/sync', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-kash-sync-key': registrationKey,
        'x-kash-sync-fingerprint': serviceSyncFingerprint(payload),
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      return {
        state: 'FAILED',
        message: String((data as { error?: unknown }).error || `Synchronization failed (${response.status}).`),
      };
    }

    return {
      state: 'SYNCED',
      lastSyncAt: new Date().toISOString(),
      message: String((data as { message?: unknown }).message || 'Synchronization confirmed.'),
    };
  } catch (error) {
    return {
      state: 'FAILED',
      message: error instanceof Error ? error.message : 'Synchronization endpoint could not be reached.',
    };
  }
}
