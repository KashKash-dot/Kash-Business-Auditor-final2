# Branding

## In-app branding — Circle Style logo
Use the approved **Circle Style Kash Business Auditor logo** for:
- Authentication / login screens
- Main navigation/sidebar branding
- Main app header
- Opened in-app pages
- Consistent in-app page branding

Asset: `public/resources/kash-business-auditor-circle-logo.png`

## Installation / device branding — 3D golden book K
Use the approved **3D golden open-book K icon** for:
- Android launcher / installation icon
- PWA/browser icon
- Apple touch icon

Asset: `public/resources/kash-business-auditor-install-icon.png`
Android template copy: `android-template/app/src/main/res/drawable/kash_business_auditor_icon.png`

Do not redesign, substitute, or swap these two approved assets.
