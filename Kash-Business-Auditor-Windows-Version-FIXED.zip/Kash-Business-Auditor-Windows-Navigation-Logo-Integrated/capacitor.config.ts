import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.kashbusinessauditor.app',
  appName: 'Kash Business Auditor',
  webDir: 'dist',
  bundledWebRuntime: false,
  server: { androidScheme: 'https' },
  plugins: {
    SplashScreen: {
      launchShowDuration: 0,
      backgroundColor: '#090909',
      showSpinner: false,
    },
  },
};

export default config;
