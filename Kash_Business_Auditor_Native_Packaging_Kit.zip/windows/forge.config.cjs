module.exports = {
  packagerConfig: {
    name: 'Kash Business Auditor',
    executableName: 'KashBusinessAuditor',
    appBundleId: 'com.kashbusinessauditor.app'
  },
  makers: [
    {
      name: '@electron-forge/maker-squirrel',
      config: {
        name: 'KashBusinessAuditor',
        setupExe: 'Kash-Business-Auditor-Setup.exe',
        noMsi: true
      }
    }
  ]
};
