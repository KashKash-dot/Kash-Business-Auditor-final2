# Kash Business Auditor — Native Packaging Kit

This kit packages the existing live Kash Business Auditor application as:

- Android APK (debug/test build)
- Windows installer/EXE (Electron Forge + Squirrel.Windows)

The native shells load the existing live application:

https://kash-business-auditor-b6wj6y.v2.appdeploy.ai/

This is intentional because the Auditor is internet-only. Business logic and backend data remain on the server, while the Android/Windows packages provide installable application experiences.

## Why this pipeline

The current Auditor source already exists and is healthy. Rebuilding the business application inside Android and Windows would duplicate logic and create another maintenance problem.

Instead:

    Kash Business Auditor web/backend
              |
              +--> Android WebView shell --> APK
              |
              +--> Windows Electron shell --> Setup.exe

A future release can update the server application without rebuilding the native shell when only web/backend code changes.

## Android

The Android project is under `android/`.

Build a debug APK:

    cd android
    gradle :app:assembleDebug

The APK is:

    android/app/build/outputs/apk/debug/app-debug.apk

For Android Studio, open the `android/` folder.

The project uses:
- applicationId: `com.kashbusinessauditor.app`
- app name: Kash Business Auditor
- minimum Android API: 26
- target/compile API: 36

A debug APK is suitable for testing. A production release APK should later be signed with a private release keystore.

## Windows

The Windows Electron package is under `windows/`.

Build:

    cd windows
    npm install
    npm run make

The installer is generated under `windows/out/`.

Electron Forge's Squirrel maker produces a Windows Setup.exe installer.

## Automated cloud build

`.github/workflows/build-native.yml` builds both packages on GitHub-hosted runners:

- Ubuntu: Android APK
- Windows: Windows installer/EXE

The workflow uploads both as GitHub Actions artifacts.

This is the key reproducible pipeline: every source revision can produce a fresh APK and Windows installer without requiring the developer machine to have Android Studio or Windows packaging tools installed.

## Important

The GitHub repository must contain the *contents* of this kit, including `.github/workflows/build-native.yml`. Uploading only a ZIP to a repository does not execute the workflow.

The current ChatGPT GitHub connector cannot see the Auditor repository, so this kit is prepared independently of that connection rather than sending us back into the same authorization loop.

## MongoDB

MongoDB Atlas should be introduced as the production database layer after native packaging is working. It is not required to produce the first installable test packages.

Current backend architecture remains:

    Client -> Auditor API -> persistent database

The MongoDB migration can then replace the AppDeploy database layer without changing the native shell architecture.
