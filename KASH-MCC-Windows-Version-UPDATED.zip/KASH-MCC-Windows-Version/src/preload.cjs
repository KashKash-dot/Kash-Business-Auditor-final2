const { contextBridge } = require('electron');
contextBridge.exposeInMainWorld('kashMcc', { appName: 'KASH Master Control Centre', version: '0.1.0' });
