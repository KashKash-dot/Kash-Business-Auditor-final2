# Windows Build Notes — Standalone Transition

- The Electron shell loads the bundled local UI from `dist/index.html` and must not load the AppDeploy website.
- The Windows build script runs `vite build` before Electron Builder.
- The bundled logo is expected at `dist/resources/kash-business-auditor-circle-logo.png`.
- The installer/executable icon is `electron/assets/kash-business-auditor-install-icon.ico`.
- Build with `npm run windows:build`; output is under `release/`.
- See `STANDALONE_ARCHITECTURE.md` for current boundaries. In particular, KMCC sync and secure shared-backend integration are not complete until a verified KMCC endpoint and authentication contract are supplied and tested.
