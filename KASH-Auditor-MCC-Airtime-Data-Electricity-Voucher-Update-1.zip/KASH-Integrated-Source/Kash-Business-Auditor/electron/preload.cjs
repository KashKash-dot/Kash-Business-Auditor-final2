'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('kashDesktop', {
  getBackendConfig: () => ipcRenderer.invoke('kash:backend-config')
});
