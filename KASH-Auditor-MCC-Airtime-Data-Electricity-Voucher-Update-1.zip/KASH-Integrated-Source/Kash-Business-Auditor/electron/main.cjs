const { app, BrowserWindow, shell, ipcMain } = require('electron');
const fs = require('node:fs');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 1024,
    minHeight: 700,
    backgroundColor: '#090909',
    autoHideMenuBar: true,
    show: false,
    icon: path.join(__dirname, 'assets', 'kash-business-auditor-install-icon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  win.once('ready-to-show', () => win.show());
  // Load the packaged local build. Never load the AppDeploy hosted application.
  win.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (event, url) => {
    if (url !== win.webContents.getURL() && !url.startsWith('file://')) event.preventDefault();
  });
}

app.whenReady().then(() => {
  ipcMain.handle('kash:backend-config', () => {
    // Config lives in the current Windows user's application-data folder, not in the app bundle.
    const configPath = path.join(app.getPath('userData'), 'kash-backend.json');
    try {
      const cfg = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      return { endpoint: String(cfg.endpoint || '').replace(/\/$/, ''), apiKey: String(cfg.apiKey || '') };
    } catch { return { endpoint: '', apiKey: '' }; }
  });
  app.setAppUserModelId('com.kashbusinessauditor.app');
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
