# Build and integration status

This source package has not yet been built or runtime-tested on Windows in this environment.

- Auditor's Windows icon and in-app logo assets are included.
- Auditor uses a standalone local data adapter for its existing UI.
- A self-hosted Node.js/SQLite backend is included under `shared-backend`.
- Auditor writes locally first and, when configured, uploads a full database snapshot to the backend. A blank local installation restores a single unambiguous snapshot.
- Auditor service sync sends business profile/subscription metadata to the configured backend.
- KMCC pulls central business profiles and pushes new profiles/status changes to the same backend.
- Configure each app with `kash-backend.json` as documented in `SHARED_BACKEND_INTEGRATION.md`.
- KMCC currently does not display individual sales, employee, stock, or expense records. Server-side subscription/trial enforcement, multi-snapshot selection, backups and restore testing remain required before production use.
