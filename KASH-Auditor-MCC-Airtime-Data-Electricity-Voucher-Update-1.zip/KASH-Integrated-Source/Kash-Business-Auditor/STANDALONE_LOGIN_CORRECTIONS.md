# Standalone login correction notes

This revision changes the standalone UI session flow only:

- Removed automatic restoration of Admin/attendant session tokens from `sessionStorage` at startup. Opening/reopening the app now returns to the local access/setup flow instead of silently restoring the previous privileged UI session.
- Sign-out now clears the local auth identity and returns to the Business Access screen rather than showing the obsolete outer sign-in screen.
- Kept `appdeploy.auth-login.json` and the original logo/icon assets. The JSON file is not deleted because it is not proven to cause HTTP 402, and deleting it could remove branding/login-screen settings without fixing the cause.

## Verification status

The source changes have been made, but a build/test could not be completed in this environment because `npm install` timed out before dependencies were installed. Do not treat this ZIP as a verified installer. Build on the configured Windows runner with `npm install` followed by `npm run windows:build`, then test first-run Admin setup, Admin login, attendant login, sign-out, logo display, and the packaged EXE/installer.

This standalone adapter uses local browser storage. It is not a secure shared backend and does not provide cross-computer synchronization. No claim is made that the previous HTTP 402 has been reproduced or conclusively diagnosed; the local source currently routes the UI through `src/lib/local-client.ts`, not a remote AppDeploy client.
