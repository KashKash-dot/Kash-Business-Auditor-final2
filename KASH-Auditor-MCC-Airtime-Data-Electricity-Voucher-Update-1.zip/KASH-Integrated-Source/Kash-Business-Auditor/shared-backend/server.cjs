'use strict';
require('dotenv').config();
const express = require('express');
const Database = require('better-sqlite3');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const apiKey = process.env.KASH_API_KEY || '';
if (apiKey.length < 32 || apiKey === 'replace-with-a-long-random-secret') {
  console.error('Refusing to start: set KASH_API_KEY to a unique secret of at least 32 characters in .env.');
  process.exit(1);
}
const host = process.env.KASH_HOST || '127.0.0.1';
const port = Number(process.env.KASH_PORT || 8787);
const dbPath = path.resolve(process.env.KASH_DB_PATH || './data/kash.sqlite');
fs.mkdirSync(path.dirname(dbPath), { recursive: true });
const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS businesses (
  business_id TEXT PRIMARY KEY,
  payload TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS sync_events (
  event_id TEXT PRIMARY KEY,
  business_id TEXT NOT NULL,
  source_app TEXT NOT NULL,
  event_type TEXT NOT NULL,
  payload TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_businesses_updated ON businesses(updated_at);
CREATE INDEX IF NOT EXISTS idx_events_business ON sync_events(business_id, created_at);
CREATE TABLE IF NOT EXISTS payments (
  payment_id TEXT PRIMARY KEY,
  business_id TEXT NOT NULL,
  reference_key TEXT NOT NULL UNIQUE,
  payload TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS auditor_data (
  business_id TEXT PRIMARY KEY,
  payload TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
`);
const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '1mb' }));
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Cache-Control', 'no-store');
  next();
});
function auth(req, res, next) {
  const supplied = String(req.get('authorization') || '').replace(/^Bearer\s+/i, '');
  const a = Buffer.from(supplied); const b = Buffer.from(apiKey);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(401).json({ error: 'UNAUTHORIZED' });
  next();
}
app.get('/health', (_req, res) => res.json({ ok: true, service: 'KASH shared backend', storage: 'sqlite', version: '0.1.0' }));
app.use('/api', auth);
const now = () => new Date().toISOString();
const json = (value) => JSON.stringify(value);
const parse = (value) => { try { return JSON.parse(value); } catch { return null; } };
const eventStmt = db.prepare('INSERT INTO sync_events(event_id,business_id,source_app,event_type,payload,created_at) VALUES(?,?,?,?,?,?)');
const saveBusiness = db.prepare(`INSERT INTO businesses(business_id,payload,updated_at,deleted) VALUES(?,?,?,0)
  ON CONFLICT(business_id) DO UPDATE SET payload=excluded.payload, updated_at=excluded.updated_at, deleted=0
  WHERE excluded.updated_at >= businesses.updated_at`);
function validBusiness(b) {
  return b && typeof b === 'object' && !Array.isArray(b) && typeof (b.businessId || b.id) === 'string' && (b.businessId || b.id).trim().length >= 3;
}
function upsertBusiness(b, sourceApp = 'unknown') {
  const id = String(b.businessId || b.id).trim();
  const stamp = b.updatedAt && !Number.isNaN(Date.parse(b.updatedAt)) ? new Date(b.updatedAt).toISOString() : now();
  const existingRow = db.prepare('SELECT payload FROM businesses WHERE business_id=? AND deleted=0').get(id);
  const existing = existingRow ? parse(existingRow.payload) : null;
  const normalized = { ...b, businessId: id, updatedAt: stamp };
  // KMCC is authoritative for central activation/suspension; Auditor profile sync must not undo it.
  if (String(sourceApp).toLowerCase().includes('auditor') && existing && ['ACTIVE','INACTIVE','SUSPENDED'].includes(String(existing.status || '').toUpperCase())) {
    normalized.status = existing.status;
  }
  const tx = db.transaction(() => {
    saveBusiness.run(id, json(normalized), stamp);
    eventStmt.run(crypto.randomUUID(), id, String(sourceApp).slice(0,40), 'BUSINESS_UPSERT', json(normalized), now());
  });
  tx();
  return normalized;
}
// Private Auditor snapshot storage. Protected by the same API key middleware.
app.get('/api/auditor-data', (req, res) => {
  const rows = db.prepare('SELECT business_id,payload,updated_at FROM auditor_data ORDER BY updated_at DESC').all();
  res.json({ items: rows.map(r => ({ businessId:r.business_id, payload:parse(r.payload), updatedAt:r.updated_at })) });
});
app.get('/api/auditor-data/:businessId', (req, res) => {
  const row = db.prepare('SELECT business_id,payload,updated_at FROM auditor_data WHERE business_id=?').get(req.params.businessId);
  if (!row) return res.status(404).json({ error: 'AUDITOR_SNAPSHOT_NOT_FOUND' });
  res.json({ businessId:row.business_id, payload:parse(row.payload), updatedAt:row.updated_at });
});
app.put('/api/auditor-data/:businessId', (req, res) => {
  const businessId = String(req.params.businessId || '').trim();
  const payload = req.body?.payload;
  if (businessId.length < 3 || !payload || typeof payload !== 'object' || Array.isArray(payload)) return res.status(400).json({ error: 'INVALID_AUDITOR_SNAPSHOT' });
  const stamp = now();
  db.prepare(`INSERT INTO auditor_data(business_id,payload,updated_at) VALUES(?,?,?)
    ON CONFLICT(business_id) DO UPDATE SET payload=excluded.payload,updated_at=excluded.updated_at`)
    .run(businessId, json(payload), stamp);
  eventStmt.run(crypto.randomUUID(), businessId, 'auditor', 'AUDITOR_SNAPSHOT_SAVED', json({ businessId, updatedAt:stamp }), stamp);
  res.json({ saved:true, businessId, updatedAt:stamp });
});

app.get('/api/businesses', (req, res) => {
  const since = req.query.since ? Date.parse(String(req.query.since)) : 0;
  if (req.query.since && Number.isNaN(since)) return res.status(400).json({ error: 'INVALID_SINCE' });
  const rows = db.prepare('SELECT payload FROM businesses WHERE deleted=0 AND updated_at >= ? ORDER BY updated_at').all(since ? new Date(since).toISOString() : '0000-01-01T00:00:00.000Z');
  res.json({ items: rows.map(r => parse(r.payload)).filter(Boolean), serverTime: now() });
});
app.post('/api/businesses', (req, res) => {
  if (!validBusiness(req.body)) return res.status(400).json({ error: 'BUSINESS_ID_REQUIRED' });
  const saved = upsertBusiness(req.body, req.get('x-kash-source') || 'mcc');
  res.status(201).json({ item: saved });
});
app.patch('/api/businesses/:id/status', (req, res) => {
  const allowed = ['ACTIVE', 'INACTIVE', 'SUSPENDED'];
  if (!allowed.includes(req.body?.status)) return res.status(400).json({ error: 'INVALID_STATUS' });
  const row = db.prepare('SELECT payload FROM businesses WHERE business_id=? AND deleted=0').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'BUSINESS_NOT_FOUND' });
  const item = { ...parse(row.payload), status: req.body.status, updatedAt: now() };
  const saved = upsertBusiness(item, req.get('x-kash-source') || 'mcc');
  res.json({ item: saved });
});
app.post('/api/sync/push', (req, res) => {
  const items = req.body?.items;
  const sourceApp = String(req.body?.sourceApp || req.get('x-kash-source') || 'unknown').slice(0,40);
  if (!Array.isArray(items) || items.length > 500) return res.status(400).json({ error: 'ITEMS_MUST_BE_ARRAY_MAX_500' });
  const accepted = [], rejected = [];
  const tx = db.transaction(() => {
    for (const b of items) {
      if (!validBusiness(b)) { rejected.push({ id: b?.id || null, reason: 'INVALID_BUSINESS_ID' }); continue; }
      const id = String(b.businessId || b.id).trim();
      const stamp = b.updatedAt && !Number.isNaN(Date.parse(b.updatedAt)) ? new Date(b.updatedAt).toISOString() : now();
      const normalized = { ...b, businessId: id, updatedAt: stamp };
      saveBusiness.run(id, json(normalized), stamp);
      eventStmt.run(crypto.randomUUID(), id, sourceApp, 'BUSINESS_UPSERT', json(normalized), now());
      accepted.push(id);
    }
  });
  tx();
  res.json({ accepted, rejected, serverTime: now() });
});
app.get('/api/sync/pull', (req, res) => {
  const since = req.query.since ? Date.parse(String(req.query.since)) : 0;
  if (req.query.since && Number.isNaN(since)) return res.status(400).json({ error: 'INVALID_SINCE' });
  const rows = db.prepare('SELECT payload FROM businesses WHERE deleted=0 AND updated_at > ? ORDER BY updated_at LIMIT 1000').all(since ? new Date(since).toISOString() : '0000-01-01T00:00:00.000Z');
  res.json({ items: rows.map(r => parse(r.payload)).filter(Boolean), serverTime: now() });
});
app.post('/api/payments', (req, res) => {
  const p = req.body;
  if (!p || typeof p.paymentId !== 'string' || typeof p.businessId !== 'string' || typeof p.reference !== 'string' || !Number.isFinite(Number(p.amount)) || Number(p.amount) <= 0) return res.status(400).json({ error: 'INVALID_PAYMENT' });
  const stamp = now();
  try {
    db.prepare('INSERT INTO payments(payment_id,business_id,reference_key,payload,created_at,updated_at) VALUES(?,?,?,?,?,?)').run(p.paymentId, p.businessId, p.reference.trim().toLowerCase(), json({ ...p, status: 'PENDING' }), stamp, stamp);
  } catch (e) {
    if (String(e.code).includes('CONSTRAINT')) return res.status(409).json({ error: 'DUPLICATE_PAYMENT_REFERENCE' });
    throw e;
  }
  res.status(201).json({ paymentId: p.paymentId, status: 'PENDING', createdAt: stamp });
});
app.get('/api/audit-events', (req, res) => {
  const limit = Math.min(500, Math.max(1, Number(req.query.limit) || 100));
  const rows = db.prepare('SELECT event_id,business_id,source_app,event_type,payload,created_at FROM sync_events ORDER BY created_at DESC LIMIT ?').all(limit);
  res.json({ items: rows.map(r => ({ eventId:r.event_id,businessId:r.business_id,sourceApp:r.source_app,eventType:r.event_type,payload:parse(r.payload),createdAt:r.created_at })) });
});
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'INTERNAL_ERROR' });
});
const server = app.listen(port, host, () => console.log(`KASH backend listening at http://${host}:${port}; SQLite: ${dbPath}`));
function shutdown() { server.close(() => { db.close(); process.exit(0); }); }
process.on('SIGINT', shutdown); process.on('SIGTERM', shutdown);
