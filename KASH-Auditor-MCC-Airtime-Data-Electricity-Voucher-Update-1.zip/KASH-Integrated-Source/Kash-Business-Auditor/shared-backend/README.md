# KASH Shared Backend

Self-hosted Node.js + SQLite API for central KASH business profiles, status, payment references and audit events.

See the parent project's `SHARED_BACKEND_INTEGRATION.md` for setup and client configuration.

- Node.js 20+
- Copy `.env.example` to `.env`; set a unique `KASH_API_KEY` (32+ characters).
- `npm install`
- `npm run check`
- `npm start`

Default binding is localhost only. Do not expose port 8787 directly to the public internet. Use a trusted private LAN or VPN for remote clients.
