# KASH shared backend integration — source package

## What is connected in this source revision

- Kash Business Auditor sends its registered business profile and subscription/trial fields to `POST /api/businesses` using the shared backend.
- KMCC is authoritative for ACTIVE/INACTIVE/SUSPENDED status; an Auditor profile sync does not overwrite a centrally managed status.
- KMCC pulls central business profiles from `GET /api/businesses`, registers new profiles with `POST /api/businesses`, and updates central statuses with `PATCH /api/businesses/:id/status`.
- Both desktop clients read backend connection settings from a user-owned `kash-backend.json` file in their Electron app-data folder. The API key is not hard-coded into the source or installer.
- The backend persists central business profiles, payment references and audit events in SQLite.

## Important boundaries

- Auditor continues to write locally first, then sends a full encrypted-in-transit HTTP snapshot of its local database (settings, employees, sales, stock, expenses and related records) to the self-hosted SQLite backend when configured. If local storage is empty and the backend contains exactly one Auditor snapshot, the adapter restores that snapshot on startup.
- KMCC receives central business profile/subscription/status metadata only. It does not display individual Auditor sales, employees, stock or expenses in its current screens.
- The current backend has a shared API-key model. Treat the key as a sensitive administrator credential. The Auditor snapshot includes business records and authentication hashes; do not distribute the key to untrusted devices or expose the backend directly to the public internet.
- No installer or live backend deployment is created by this source ZIP. The source must be built and tested on Windows.
- To synchronize two computers without a third-party hosted database, run the backend on a computer you control and connect clients over a trusted LAN or private VPN. Do not expose port 8787 directly to the internet. If the host PC is off, synchronization is unavailable.
- The 32-day trial and payment status still require authoritative server-side enforcement and payment confirmation workflow before production use.

## Run the backend on the computer you control

1. Install Node.js 20 or newer on the host Windows computer.
2. Open a terminal in `shared-backend`.
3. Copy `.env.example` to `.env`.
4. Generate a random API key of at least 32 characters and set `KASH_API_KEY` in `.env`.
5. Keep `KASH_HOST=127.0.0.1` for same-computer testing. For trusted LAN clients only, set `KASH_HOST=0.0.0.0`, configure Windows Firewall for your private network, and use the host computer's private LAN IP. Prefer a private VPN for remote access.
6. Run `npm install`, then `npm start`. The SQLite database is stored at the path configured by `KASH_DB_PATH`.

## Configure each Windows app

Create `kash-backend.json` in that app's Electron user-data directory with this shape:

```json
{
  "endpoint": "http://127.0.0.1:8787",
  "apiKey": "PASTE_THE_SAME_RANDOM_API_KEY_HERE"
}
```

For standard Electron builds, the app-data directory is under `%APPDATA%` in a folder named after the application. The Auditor and MCC may use different folders; create the same configuration in each. For another computer, replace `127.0.0.1` with the host's private LAN IP or VPN address.

## Verification checklist

- Start backend and confirm `GET /health` reports `ok: true`.
- Open Auditor, register a business, and trigger its service synchronization action.
- Open MCC and verify that the same Business ID appears.
- Change status in MCC and verify that a subsequent Auditor sync overwrites or refreshes the profile as expected.
- Restart both apps and the backend; confirm central profiles remain in SQLite.
- Test with the host offline and confirm the clients report a sync failure rather than claiming success.

Do not use for live financial processing until authentication, backup/restore, server-side role authorization, conflict handling, and trial/payment enforcement have been reviewed.
