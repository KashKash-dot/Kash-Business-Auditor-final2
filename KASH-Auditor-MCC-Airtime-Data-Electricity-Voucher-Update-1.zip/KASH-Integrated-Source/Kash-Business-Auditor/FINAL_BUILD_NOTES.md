# Kash Business Auditor — current build status

This archive contains a standalone-desktop transition, not a verified production release.

## Implemented in this source revision
- Electron loads the local Vite UI instead of the AppDeploy hosted URL.
- The AppDeploy browser-client import is redirected to a local-first adapter so the UI can be bundled without the AppDeploy-injected module.
- Windows build scripts build the UI first, then package an NSIS installer and portable executable.
- Existing logo and icon assets remain configured in their intended locations.

## Not yet production-verified
- The full app build was not run in this environment because dependency installation timed out.
- KMCC synchronization is not configured or verified; the adapter reports `NOT_CONFIGURED` instead of falsely claiming success.
- The local adapter uses Chromium localStorage and is not a hardened secure shared backend. Do not use it as the final architecture for multi-device business data or authoritative subscription enforcement.
- Production-grade central authentication, trial/subscription enforcement, KMCC synchronization, payment-provider integration, and airtime-provider integration still require a verified backend/API contract and tests.

See `STANDALONE_ARCHITECTURE.md` for the exact scope and next integration requirements.
