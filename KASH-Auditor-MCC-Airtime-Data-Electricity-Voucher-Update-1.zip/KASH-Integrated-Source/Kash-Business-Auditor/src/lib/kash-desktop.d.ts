export {};
declare global {
  interface Window {
    kashDesktop?: {
      getBackendConfig: () => Promise<{ endpoint: string; apiKey: string }>;
    };
  }
}
