# Kash Business Auditor — standalone desktop transition

## Changes in this revision
- Electron now loads the locally bundled Vite build from `dist/index.html`; it no longer opens the AppDeploy-hosted URL.
- The Vite build aliases the AppDeploy-injected browser client to `src/lib/local-client.ts`, allowing the desktop UI to compile without `@appdeploy/client`.
- The adapter stores records locally in the current Windows user's Chromium localStorage and implements the existing UI's main CRUD/login calls.
- When configured, each local write also posts a full Auditor snapshot to the self-hosted SQLite backend; an empty local installation can restore a single unambiguous snapshot.
- The Windows build scripts now run Vite before Electron Builder and include `dist/**/*` in the packaged app.
- The existing `.ico` is still configured as the Windows executable/installer icon; the in-app logo is bundled from `public/resources` into `dist/resources`.
- The GitHub Actions workflow now runs the local build script and prefers the reviewed source ZIP filename.

## Important current limitations — do not treat as production-ready yet
- This is a standalone/local-first transition, not the completed secure shared-backend architecture. Local browser storage is not a tamper-proof database and should not be treated as the sole protection for sensitive business records.
- This revision adds an opt-in connection to the included self-hosted KASH backend for business profile/subscription metadata. Configure the endpoint and API key in the per-user `kash-backend.json` file described in `SHARED_BACKEND_INTEGRATION.md`.
- The backend stores an Auditor snapshot as a backup/restore path, but KMCC's UI currently displays business profile/subscription/status metadata only; individual sales, employees, stock and expenses are not shown inside KMCC.
- The local adapter does not provide authoritative remote subscription enforcement, central trial enforcement, multi-computer data sharing, or a production payment/airtime provider integration. Airtime remains recorded as `Provider Not Connected`.
- Do not use this build for real payment processing or assume KMCC sync is working. The next required integration step is to connect to a verified KMCC endpoint using an authentication design that does not expose a shared secret in the client.

## Build
Run `npm install` then `npm run windows:build` on Windows or in the configured Windows GitHub Actions runner. The build should produce an NSIS installer and a portable EXE under `release/`.
