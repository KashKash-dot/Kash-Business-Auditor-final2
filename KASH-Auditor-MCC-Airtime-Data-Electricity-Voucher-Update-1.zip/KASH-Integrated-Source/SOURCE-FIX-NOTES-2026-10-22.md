# KASH source fixes — 22 October 2026

This is a source-only repair package based on `KASH-Auditor-MCC-Airtime-Data-Electricity-Voucher-Update.zip`.

## Changed

- KMCC now renders the supplied `kash-mcc-logo.svg` in the in-app sidebar and `kash-mcc-network-logo.png` in the overview. The installer icon assets are untouched.
- KMCC System Settings can save the shared backend endpoint and API key to the Electron user's app-data `kash-backend.json` file. It has a backend health/authenticated API connection test.
- KMCC refuses to report business registration as successful unless the shared backend accepts the registration. Failed registrations are clearly reported as unconfirmed; no local-only registration is falsely presented as synced.
- KBA's asynchronous snapshot sync records `SYNCED`, `NOT_CONFIGURED`, `PENDING`, or `FAILED` status in its local data instead of silently discarding all errors. Its service-sync status route returns the snapshot status/message.
- KBA login and Admin settings actions surface unconfirmed business-profile sync errors.
- Embedded KMCC build workflow now checks that the in-app logo assets exist, separately from the installer icon.

## What is not done by this ZIP alone

- The shared backend has not been deployed by this source edit. It must be started on a computer/server you control.
- The API key and backend URL must be configured in both apps. The same key must match the backend's `KASH_API_KEY`.
- No Windows EXE installer has been built or live two-app synchronization test has been run here. Source syntax checks are not the same as a successful Windows build or live backend test.

## Configure for same-PC testing

1. On the Windows host, open `shared-backend` and install Node.js 20+.
2. Copy `.env.example` to `.env`; replace `KASH_API_KEY` with a unique random secret at least 32 characters long. Keep `KASH_HOST=127.0.0.1` for same-PC testing.
3. Run `npm install`, then `npm start`. Check `http://127.0.0.1:8787/health` and confirm the response contains `"ok":true`.
4. In KMCC → System Settings, enter `http://127.0.0.1:8787` and the same API key, save, then use Test Connection.
5. For KBA, create `kash-backend.json` in the Auditor Electron app-data directory with:
   `{ "endpoint": "http://127.0.0.1:8787", "apiKey": "THE_SAME_SECRET" }`
   The directory is the app's Electron `app.getPath('userData')` folder, normally under `%APPDATA%`. Do not place this file inside the source ZIP or commit it to GitHub.
6. Save the KBA Admin Dashboard business profile and verify that the UI reports backend synchronization. Then open KMCC and verify the same business ID appears. Close and reopen KBA and confirm the profile remains.

For another computer, use the backend host's private LAN/VPN address and HTTPS where applicable; do not expose port 8787 directly to the public internet. Never commit the real API key.
