# KASH Master Control Centre — Windows Edition

This is a **starter source package** for the separate Windows KASH MCC application. It is not the Kash Business Auditor application and is not yet a production-ready MCC deployment.

## Included in this starter
- Black-and-gold Windows desktop shell built with Electron.
- Overview, Business Profiles, Register Business, Auditor Updates and System Settings pages.
- Local preview registration with generated profile IDs, ACTIVE / INACTIVE / SUSPENDED states, days remaining and permitted sales points/tellers.
- Draft release-record UI for future Kash Business Auditor updates.
- GitHub Actions workflow to build a Windows installer and portable `.exe` and upload them as workflow artifacts.

## Important limits
- Business profiles are stored locally in the app preview; no backend/API is configured.
- No real subscription verification, payment processing, remote suspension, centralized report storage, device synchronization, or update deployment is implemented.
- The included icon branding is a simple KASH MCC placeholder. Replace it with the approved original KASH logo and a Windows `.ico` before claiming final branding.
- Do not use this preview to manage real customer or identity data.

## Build on Windows / GitHub Actions
1. Install Node.js 22.
2. Run `npm install`.
3. Run `npm test` for JavaScript syntax checks.
4. Run `npm start` to open the preview.
5. Run `npm run dist` to create Windows installer and portable executable under `release/`.

The GitHub Actions workflow at `.github/workflows/windows.yml` performs these steps on a Windows runner. The resulting executables must still be installed and manually tested on a Windows PC.

## Shared backend source included in this bundle

The sibling `kash-backend/` folder contains a self-hosted Node.js + SQLite API starter. It stores its database on the computer controlled by the operator and does not depend on AppDeploy or a third-party database. It is not wired into the MCC renderer or Auditor yet; cross-device synchronization is therefore NOT complete. Read `kash-backend/README.md` for constraints and setup.

## Production work remaining
1. Confirm final MCC logo and icon assets.
2. Implement authenticated backend/API and database.
3. Add administrator sign-in, role-based access and audit trail.
4. Implement secure business registration, unique IDs, subscription status and teller limits.
5. Implement secure, signed release management for Kash Business Auditor with staged rollout and rollback.
6. Add centralized reporting and reliable background synchronization.
7. Test on a Windows PC and perform end-to-end tests with a separate Auditor client.


## Payment verification and designated bank accounts (v0.2.0)

- Configure multiple designated receiving bank accounts, including bank, beneficiary, account number, branch code, account type, payment-reference instructions, active/inactive state and default account.
- Record business payments as PENDING, then manually confirm or reject them after an independent bank transaction check. Duplicate payment references are blocked in the local preview.
- Confirmation records an administrator identifier and timestamp and adds the configured subscription days to the business profile.
- **KASH MCC does not receive, hold, initiate, or process money.** Business administrators pay directly to the designated bank account.
- The current starter is a local demonstration only: it has no bank connection, automated verification, encrypted shared database, real authentication, or multi-device sync. Do not use local preview data as proof that funds have cleared. A secure backend, role-based administrator access, durable audit log, and authorized bank statement/feed integration are required before production. Never store online banking credentials, PINs, CVVs, or OTPs.
