'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('kashMcc', {
  appName: 'KASH Master Control Centre',
  version: '0.2.1',
  getBackendConfig: () => ipcRenderer.invoke('kash-mcc:backend-config'),
  saveBackendConfig: (config) => ipcRenderer.invoke('kash-mcc:save-backend-config', config)
});
