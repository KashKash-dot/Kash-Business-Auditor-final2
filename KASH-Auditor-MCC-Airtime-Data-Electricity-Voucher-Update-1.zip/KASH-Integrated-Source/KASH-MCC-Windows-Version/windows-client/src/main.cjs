const { app, BrowserWindow, shell, ipcMain } = require('electron');
const fs = require('node:fs');
const path = require('path');
function createWindow() {
  const win = new BrowserWindow({
    width: 1440, height: 920, minWidth: 1080, minHeight: 700,
    title: 'KASH Master Control Centre',
    icon: path.join(__dirname, '..', 'build', 'kash-mcc-installation-icon.png'),
    backgroundColor: '#090909',
    webPreferences: { preload: path.join(__dirname, 'preload.cjs'), contextIsolation: true, nodeIntegration: false }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
}
app.whenReady().then(() => {
  const configPath = path.join(app.getPath('userData'), 'kash-backend.json');
  ipcMain.handle('kash-mcc:backend-config', () => {
    try {
      const cfg = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      return { endpoint: String(cfg.endpoint || '').replace(/\/$/, ''), apiKey: String(cfg.apiKey || '') };
    } catch { return { endpoint: '', apiKey: '' }; }
  });
  ipcMain.handle('kash-mcc:save-backend-config', (_event, input) => {
    const endpoint = String(input?.endpoint || '').trim().replace(/\/$/, '');
    const apiKey = String(input?.apiKey || '').trim();
    let parsed;
    try { parsed = new URL(endpoint); } catch { throw new Error('Enter a valid backend URL.'); }
    const localHttp = parsed.protocol === 'http:' && (parsed.hostname === 'localhost' || parsed.hostname === '127.0.0.1' || /^10\./.test(parsed.hostname) || /^192\.168\./.test(parsed.hostname) || /^172\.(1[6-9]|2[0-9]|3[01])\./.test(parsed.hostname));
    if (parsed.protocol !== 'https:' && !localHttp) throw new Error('Use HTTPS, or HTTP only for localhost/private LAN testing.');
    if (apiKey.length < 32 || /replace-with|paste_the_same/i.test(apiKey)) throw new Error('Enter the real shared API key (at least 32 characters), not the example placeholder.');
    fs.mkdirSync(path.dirname(configPath), { recursive: true });
    fs.writeFileSync(configPath, JSON.stringify({ endpoint, apiKey }, null, 2), { encoding: 'utf8', mode: 0o600 });
    return { saved: true, endpoint };
  });
  createWindow(); app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); }); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
