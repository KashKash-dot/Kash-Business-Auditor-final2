const { app, BrowserWindow, shell, ipcMain } = require('electron');
const fs = require('node:fs');
const path = require('path');
function createWindow() {
  const win = new BrowserWindow({
    width: 1440, height: 920, minWidth: 1080, minHeight: 700,
    title: 'KASH Master Control Centre',
    icon: path.join(__dirname, '..', 'build', 'kash-mcc-installation-icon.png'),
    backgroundColor: '#090909',
    webPreferences: { preload: path.join(__dirname, 'preload.cjs'), contextIsolation: true, nodeIntegration: false }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
}
app.whenReady().then(() => {
  ipcMain.handle('kash-mcc:backend-config', () => {
    const configPath = path.join(app.getPath('userData'), 'kash-backend.json');
    try {
      const cfg = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      return { endpoint: String(cfg.endpoint || '').replace(/\/$/, ''), apiKey: String(cfg.apiKey || '') };
    } catch { return { endpoint: '', apiKey: '' }; }
  }); createWindow(); app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); }); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
