const STORE='kash-mcc-preview-businesses-v1', BANKS='kash-mcc-preview-bank-accounts-v1', PAYMENTS='kash-mcc-preview-payments-v1';
const $=id=>document.getElementById(id);
function load(key){try{const v=JSON.parse(localStorage.getItem(key)||'[]');return Array.isArray(v)?v:[]}catch{return []}}
let businesses=load(STORE), bankAccounts=load(BANKS), payments=load(PAYMENTS);
function saveAll(){localStorage.setItem(STORE,JSON.stringify(businesses));localStorage.setItem(BANKS,JSON.stringify(bankAccounts));localStorage.setItem(PAYMENTS,JSON.stringify(payments));render();}
async function backendRequest(path, options={}){
  const cfg=await window.kashMcc?.getBackendConfig?.();
  if(!cfg?.endpoint||!cfg?.apiKey) throw new Error('Shared backend is not configured. Set kash-backend.json in the MCC app data folder.');
  const response=await fetch(cfg.endpoint+path,{...options,headers:{'content-type':'application/json','authorization':'Bearer '+cfg.apiKey,'x-kash-source':'mcc',...(options.headers||{})}});
  const data=await response.json().catch(()=>({}));
  if(!response.ok) throw new Error(data.error||('Backend request failed ('+response.status+')'));
  return data;
}
function fromBackend(b){return {id:String(b.businessId||b.id),name:String(b.businessName||b.name||''),owner:String(b.ownerName||b.owner||''),address:String(b.address||''),phone:String(b.phone||''),email:String(b.email||''),identity:String(b.ownerIdNumber||b.identity||''),status:String(b.status||'INACTIVE').toUpperCase(),days:Math.max(0,Number(b.daysRemaining??b.days)||0),tellers:Math.max(1,Number(b.tellers)||1),businessId:String(b.businessId||b.id),updatedAt:b.updatedAt};}
async function syncFromBackend(){
  try{
    const data=await backendRequest('/api/businesses');
    const remote=(data.items||[]).map(fromBackend);
    const map=new Map(businesses.map(b=>[String(b.id),b]));
    for(const b of remote) map.set(String(b.id),{...(map.get(String(b.id))||{}),...b});
    businesses=[...map.values()];localStorage.setItem(STORE,JSON.stringify(businesses));render();
    const el=$('backendStatus'); if(el) el.textContent='Shared backend connected · '+remote.length+' profile(s) received';
  }catch(error){const el=$('backendStatus');if(el)el.textContent=error.message;}
}
async function pushBusinessToBackend(b){
  const payload={businessId:String(b.businessId||b.id),id:String(b.businessId||b.id),businessName:b.name,name:b.name,ownerName:b.owner,ownerIdNumber:b.identity,address:b.address,phone:b.phone,email:b.email,status:b.status,daysRemaining:b.days,tellers:b.tellers,sourceApp:'KASH MCC',updatedAt:new Date().toISOString()};
  const data=await backendRequest('/api/businesses',{method:'POST',body:JSON.stringify(payload)});
  return data.item;
}

function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function badge(status){const cls=status==='ACTIVE'||status==='CONFIRMED'?'green':status==='SUSPENDED'||status==='REJECTED'?'red':'grey';return `<span class="tag ${cls}">${esc(status)}</span>`;}
function cash(n){return Number(n||0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2});}
function render(){
 $('totalCount').textContent=businesses.length;$('activeCount').textContent=businesses.filter(b=>b.status==='ACTIVE').length;$('inactiveCount').textContent=businesses.filter(b=>b.status==='INACTIVE').length;$('suspendedCount').textContent=businesses.filter(b=>b.status==='SUSPENDED').length;
 $('pendingPaymentCount').textContent=payments.filter(p=>p.status==='PENDING').length;$('confirmedPaymentCount').textContent=payments.filter(p=>p.status==='CONFIRMED').length;
 const recent=businesses.slice(-5).reverse();$('recentRows').innerHTML=recent.length?recent.map(b=>`<tr><td><b>${esc(b.name)}</b></td><td>${esc(b.id)}</td><td>${badge(b.status)}</td><td>${Number(b.days)||0}</td><td>${Number(b.tellers)||1}</td></tr>`).join(''):'<tr><td colspan="5" class="empty">No business profiles yet. Select “Register Business” to add a test profile.</td></tr>';
 const q=($('searchBusiness')?.value||'').toLowerCase(),f=$('statusFilter')?.value||'ALL';const rows=businesses.filter(b=>(f==='ALL'||b.status===f)&&[b.name,b.owner,b.id].some(v=>String(v).toLowerCase().includes(q))).slice().reverse();$('businessRows').innerHTML=rows.length?rows.map(b=>`<tr><td><b>${esc(b.name)}</b><br><small>${esc(b.phone||'')}</small></td><td>${esc(b.owner)}</td><td>${esc(b.id)}</td><td>${badge(b.status)}</td><td>${Number(b.days)||0}</td><td>${Number(b.tellers)||1}</td><td><select aria-label="Change preview status" onchange="changeStatus('${esc(b.id)}',this.value)"><option ${b.status==='ACTIVE'?'selected':''}>ACTIVE</option><option ${b.status==='INACTIVE'?'selected':''}>INACTIVE</option><option ${b.status==='SUSPENDED'?'selected':''}>SUSPENDED</option></select></td></tr>`).join(''):'<tr><td colspan="7" class="empty">No profiles found.</td></tr>';
 renderBanks();renderPaymentOptions();renderPayments();
}
window.changeStatus=async(id,status)=>{const b=businesses.find(x=>x.id===id);if(b){b.status=status;saveAll();try{await backendRequest('/api/businesses/'+encodeURIComponent(id)+'/status',{method:'PATCH',body:JSON.stringify({status})});const el=$('backendStatus');if(el)el.textContent='Status saved to shared backend.';}catch(error){const el=$('backendStatus');if(el)el.textContent='Local status saved; backend sync failed: '+error.message;}}};

// Airtime & Data Sales module — presentation scaffold only.
// Production must load records from authenticated shared-backend APIs and provider feeds.
// Do not seed fictitious transactions or treat local browser storage as an authoritative ledger.
function renderAirtimeModule(){
  const merchants = [];
  const sales = [];
  const merchantRows = $('airtimeMerchantRows');
  const salesRows = $('airtimeSalesRows');
  if (merchantRows && !merchantRows.dataset.initialized) {
    merchantRows.innerHTML = '<tr><td colspan="6" class="empty">No live authorization records. Connect the provider authorization API before enabling merchants.</td></tr>';
    merchantRows.dataset.initialized = '1';
  }
  if (salesRows && !salesRows.dataset.initialized) {
    salesRows.innerHTML = '<tr><td colspan="8" class="empty">No airtime/data sales loaded. Production records must come from authenticated Auditor sync and provider reports/API.</td></tr>';
    salesRows.dataset.initialized = '1';
  }
  if ($('airtimeAuthorizedCount')) $('airtimeAuthorizedCount').textContent = String(merchants.length);
  if ($('airtimeSalesCount')) $('airtimeSalesCount').textContent = String(sales.length);
  if ($('airtimeMismatchCount')) $('airtimeMismatchCount').textContent = String(sales.filter(s=>s.reconciliationStatus==='MISMATCH').length);
  if ($('airtimeCommissionTotal')) $('airtimeCommissionTotal').textContent = 'R0.00';
}
function exportAirtimeLedger(){
  const csv = 'transactionId,businessId,provider,product,saleAmount,providerStatus,reconciliationStatus,commissionAmount\r\n';
  const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = 'kash-airtime-data-reconciliation-template.csv';
  document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
}

function navigate(page){document.querySelectorAll('.page').forEach(p=>p.classList.toggle('hidden',p.id!==page));document.querySelectorAll('.nav').forEach(n=>n.classList.toggle('active',n.dataset.page===page));const titles={overview:'Overview',businesses:'Business Profiles',registrations:'Register Business',payments:'Payment Verification',airtime:'Airtime & Data Sales',bankAccounts:'Bank Account Settings',updates:'Auditor Updates',settings:'System Settings'};$('pageTitle').textContent=titles[page]||'Overview';if(page==='airtime')renderAirtimeModule();}
document.querySelectorAll('.nav').forEach(n=>n.addEventListener('click',()=>navigate(n.dataset.page)));
['addBusiness','addBusiness2'].forEach(id=>$(id).addEventListener('click',()=>navigate('registrations')));
$('businessForm').addEventListener('submit',async e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.currentTarget).entries());const id='KMC-'+Date.now().toString().slice(-8);const b={id,businessId:id,name:d.name.trim(),owner:d.owner.trim(),address:d.address,phone:d.phone,email:d.email,identity:d.identity,status:d.status,days:Math.max(0,Number(d.days)||0),tellers:Math.max(1,Number(d.tellers)||1)};const msg=$('formMessage');msg.textContent='Contacting shared backend…';try{const saved=await pushBusinessToBackend(b);const normalized=fromBackend(saved||b);businesses=businesses.filter(x=>String(x.id)!==id);businesses.push(normalized);saveAll();e.currentTarget.reset();msg.textContent=`Business registered in shared backend and synchronized: ${id}`;await syncFromBackend();}catch(error){msg.textContent=`Registration was NOT confirmed by the backend. Nothing has been reported as synchronized. Error: ${error.message}`;}});
$('searchBusiness').addEventListener('input',render);$('statusFilter').addEventListener('change',render);
$('bankAccountForm').addEventListener('submit',e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.currentTarget).entries());const isDefault=e.currentTarget.elements.isDefault.checked;if(isDefault)bankAccounts.forEach(a=>a.isDefault=false);const account={id:'BANK-'+Date.now().toString().slice(-8),bankName:d.bankName.trim(),accountHolder:d.accountHolder.trim(),accountNumber:d.accountNumber.trim(),branchCode:d.branchCode.trim(),accountType:d.accountType,referenceInstructions:d.referenceInstructions.trim(),status:d.status,isDefault};if(!bankAccounts.length&&!bankAccounts.some(a=>a.isDefault))account.isDefault=true;bankAccounts.push(account);saveAll();e.currentTarget.reset();$('bankMessage').textContent='Bank account saved to this local preview. No bank connection has been made.';});
function renderBanks(){const body=$('bankAccountRows');if(!body)return;body.innerHTML=bankAccounts.length?bankAccounts.map(a=>`<tr><td>${esc(a.bankName)}</td><td>${esc(a.accountHolder)}</td><td>${esc(a.accountNumber)}</td><td>${esc(a.branchCode||'—')}</td><td>${badge(a.status)}</td><td>${a.isDefault?'<span class="tag green">DEFAULT</span>':'—'}</td><td><button class="secondary smallbtn" onclick="toggleBank('${esc(a.id)}')">${a.status==='ACTIVE'?'Deactivate':'Activate'}</button> <button class="secondary smallbtn" onclick="setDefaultBank('${esc(a.id)}')">Set Default</button></td></tr>`).join(''):'<tr><td colspan="7" class="empty">No bank accounts configured.</td></tr>';}
window.toggleBank=id=>{const a=bankAccounts.find(x=>x.id===id);if(a){a.status=a.status==='ACTIVE'?'INACTIVE':'ACTIVE';if(a.status!=='ACTIVE'&&a.isDefault){a.isDefault=false;const next=bankAccounts.find(x=>x.status==='ACTIVE');if(next)next.isDefault=true;}saveAll();}};
window.setDefaultBank=id=>{const a=bankAccounts.find(x=>x.id===id);if(!a||a.status!=='ACTIVE'){alert('Only an active bank account can be the default.');return;}bankAccounts.forEach(x=>x.isDefault=x.id===id);saveAll();};
function renderPaymentOptions(){const bs=$('paymentBusiness'),as=$('paymentAccount');if(!bs||!as)return;const bv=bs.value,av=as.value;bs.innerHTML='<option value="">Select business…</option>'+businesses.map(b=>`<option value="${esc(b.id)}">${esc(b.name)} (${esc(b.id)})</option>`).join('');as.innerHTML='<option value="">Select active account…</option>'+bankAccounts.filter(a=>a.status==='ACTIVE').map(a=>`<option value="${esc(a.id)}">${esc(a.bankName)} · ${esc(a.accountHolder)} · ${esc(a.accountNumber)}</option>`).join('');if(businesses.some(b=>b.id===bv))bs.value=bv;if(bankAccounts.some(a=>a.id===av&&a.status==='ACTIVE'))as.value=av;else{const def=bankAccounts.find(a=>a.status==='ACTIVE'&&a.isDefault);if(def)as.value=def.id;}}
$('paymentForm').addEventListener('submit',e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.currentTarget).entries());if(!businesses.some(b=>b.id===d.businessId)){ $('paymentMessage').textContent='Choose a registered business first.';return;}const a=bankAccounts.find(x=>x.id===d.accountId&&x.status==='ACTIVE');if(!a){$('paymentMessage').textContent='Choose an active receiving account first.';return;}if(payments.some(p=>p.reference.trim().toLowerCase()===d.reference.trim().toLowerCase())){ $('paymentMessage').textContent='That payment reference already exists. Check for a duplicate before recording.';return;}const b=businesses.find(x=>x.id===d.businessId);payments.push({id:'PAY-'+Date.now().toString().slice(-8),businessId:b.id,businessName:b.name,accountId:a.id,accountLabel:`${a.bankName} · ${a.accountNumber}`,amount:Number(d.amount),reference:d.reference.trim(),paymentDate:d.paymentDate,daysToAdd:Number(d.daysToAdd),notes:d.notes.trim(),status:'PENDING',createdAt:new Date().toISOString(),confirmedAt:null,confirmedBy:null});saveAll();e.currentTarget.reset();$('paymentForm').elements.daysToAdd.value='32';$('paymentForm').elements.paymentDate.value=new Date().toISOString().slice(0,10);$('paymentMessage').textContent='Payment recorded as PENDING. This does not confirm that money has reached the bank account.';});
function renderPayments(){const body=$('paymentRows');if(!body)return;const q=($('searchPayment')?.value||'').toLowerCase(),f=$('paymentStatusFilter')?.value||'ALL';const list=payments.filter(p=>(f==='ALL'||p.status===f)&&[p.businessName,p.businessId,p.reference].some(v=>String(v).toLowerCase().includes(q))).slice().reverse();body.innerHTML=list.length?list.map(p=>`<tr><td><b>${esc(p.businessName)}</b><br><small>${esc(p.businessId)}</small></td><td>${cash(p.amount)}</td><td>${esc(p.reference)}</td><td>${esc(p.accountLabel)}</td><td>${esc(p.paymentDate)}</td><td>${badge(p.status)}</td><td>${p.status==='PENDING'?`<button class="primary smallbtn" onclick="confirmPayment('${esc(p.id)}')">Confirm</button> <button class="secondary smallbtn" onclick="rejectPayment('${esc(p.id)}')">Reject</button>`:esc(p.confirmedBy||'Reviewed')}</td></tr>`).join(''):'<tr><td colspan="7" class="empty">No payments match this filter.</td></tr>';}
window.confirmPayment=id=>{const p=payments.find(x=>x.id===id);if(!p||p.status!=='PENDING')return;const b=businesses.find(x=>x.id===p.businessId);if(!b){alert('The registered business was not found. Payment was not confirmed.');return;}if(!confirm(`Confirm payment ${p.reference} for ${p.businessName}? Only proceed after independently checking the actual bank transaction.`))return;const reviewer=prompt('Enter the authorized MCC administrator name/ID for the audit log:');if(!reviewer||!reviewer.trim()){alert('Confirmation cancelled. An administrator identifier is required.');return;}p.status='CONFIRMED';p.confirmedAt=new Date().toISOString();p.confirmedBy=reviewer.trim();b.days=Math.max(0,Number(b.days)||0)+Math.max(1,Number(p.daysToAdd)||32);if(b.status==='INACTIVE')b.status='ACTIVE';saveAll();alert(`Payment recorded as confirmed in this local preview. ${p.daysToAdd} subscription days added to ${b.name}. This app has not independently verified the bank transaction.`);};
window.rejectPayment=id=>{const p=payments.find(x=>x.id===id);if(!p||p.status!=='PENDING')return;const reason=prompt('Enter reason for rejection (required):');if(!reason||!reason.trim())return;p.status='REJECTED';p.rejectionReason=reason.trim();p.confirmedBy='Rejected by administrator';saveAll();};
$('searchPayment').addEventListener('input',renderPayments);$('paymentStatusFilter').addEventListener('change',renderPayments);
$('prepareUpdate').addEventListener('click',()=>{const version=$('releaseVersion').value.trim();if(!version){$('updateMessage').classList.remove('hidden');$('updateMessage').textContent='Enter a release version first. No update has been deployed.';return;}$('updateMessage').classList.remove('hidden');$('updateMessage').innerHTML=`<b>Draft release record only</b><p>Version ${esc(version)} · ${esc($('releaseChannel').value)} channel</p><p>${esc($('releaseNotes').value||'No release notes provided.')}</p><p>No devices have been updated. Backend and signed release pipeline are not connected.</p>`;});
async function loadBackendSettings(){const cfg=await window.kashMcc?.getBackendConfig?.()||{endpoint:'',apiKey:''};$('apiUrl').value=cfg.endpoint||'';$('apiKey').value=cfg.apiKey||'';}
$('saveSettings').addEventListener('click',async()=>{const msg=$('backendConfigMessage');msg.textContent='';try{const result=await window.kashMcc.saveBackendConfig({endpoint:$('apiUrl').value,apiKey:$('apiKey').value});msg.textContent='Backend configuration saved. Testing connection…';await syncFromBackend();}catch(error){msg.textContent='Configuration was not saved: '+error.message;}});
$('testBackend').addEventListener('click',async()=>{const msg=$('backendConfigMessage');msg.textContent='Testing shared backend…';try{const cfg=await window.kashMcc?.getBackendConfig?.();if(!cfg?.endpoint||!cfg?.apiKey)throw new Error('Save the backend URL and API key first.');const response=await fetch(cfg.endpoint+'/health',{cache:'no-store'});if(!response.ok)throw new Error('Health check failed ('+response.status+').');const data=await response.json();if(!data.ok)throw new Error('Backend health response did not confirm readiness.');await backendRequest('/api/businesses');msg.textContent='Connection successful. Backend health and authenticated business API both responded.';await syncFromBackend();}catch(error){msg.textContent='Connection test failed: '+error.message;}});
$('airtimeExportBtn')?.addEventListener('click',exportAirtimeLedger);$('appVersion').textContent=window.kashMcc?.version||'0.2.2';$('paymentForm').elements.paymentDate.value=new Date().toISOString().slice(0,10);render();
loadBackendSettings();
// Pull central business records when the MCC opens.
syncFromBackend();
