# KASH Airtime & Data Sales — Implementation Contract

## Scope
A dedicated KMCC module for provider-authorized merchants, Auditor-originated transaction records, provider-side confirmation, reconciliation, and commission reporting. Merchants collect customer payments using their own methods. KASH does not custody those payments in this model.

## Current source status
The KMCC page and navigation entry in this package are a **presentation scaffold only**. It intentionally shows no fabricated transactions and does not claim live authorization or provider integration. Existing shared-backend synchronization code was not modified by this change. Do not use this module for production commission claims until the APIs below are implemented, authenticated, and tested.

## Required backend records
- `airtime_authorizations`: authorization_id, business_id, provider_id, provider_merchant_ref, status, valid_from, valid_until, evidence_ref, verified_at, verified_by, created_at, updated_at.
- `airtime_transactions`: transaction_id (globally unique idempotency key), business_id, auditor_sale_id, provider_id, provider_transaction_ref, product_type, product_code, face_value, retail_amount, supplier_cost (when supplied), currency, initiated_at, provider_confirmed_at, provider_status, reversal_of, source_event_hash, created_at.
- `airtime_reconciliation_runs`: run_id, provider_id, period_start, period_end, statement_ref, imported_at, imported_by, matched_count, mismatch_count, unmatched_provider_count, status.
- `airtime_reconciliation_items`: run_id, transaction_id, provider_transaction_ref, match_status, mismatch_reason, evidence_json, resolved_at, resolved_by.
- `airtime_commission_rules`: provider_id, product_code or product_type, rate_type, rate_value, effective_from, effective_until, agreement_ref.
- `airtime_commission_statements`: statement_id, provider_id, period_start, period_end, gross_eligible_sales, commission_due, currency, provider_statement_ref, status, disputed_amount, reconciled_at.

## Required API contract
- `GET /api/airtime/authorizations?businessId=...` — return provider-verified authorization status; only server-verified `ACTIVE` authorizations enable the Auditor feature.
- `POST /api/airtime/authorizations` — submit an authorization application or evidence; cannot self-approve.
- `POST /api/airtime/transactions` — idempotent transaction event from an authenticated Auditor client; server stamps receipt time and records source identity.
- `GET /api/airtime/transactions` — role-scoped ledger search/export for authorized KASH operators.
- `POST /api/airtime/provider-imports` — privileged upload/import of provider statement or API response; validate source and retain import evidence.
- `POST /api/airtime/reconciliation-runs` — reconcile KASH events against provider data and return match/mismatch/unmatched counts.
- `GET /api/airtime/commissions` — calculate only under signed/effective provider agreement rules and agreed successful/reversal policy.
- `POST /api/airtime/disputes` — create a dispute with evidence and append-only status history.

All endpoints require authenticated identities and role/business-level authorization. The current shared backend's single API-key middleware is not sufficient for multi-merchant production access; do not expose that global key inside end-user apps. Use server-to-server credentials, per-user/business authorization, rate limits, audit logging, TLS, and secret rotation.

## Reconciliation rules
1. Auditor's local sale is a reported event, not proof of successful provider fulfillment.
2. Provider API/statement is independently ingested and retained as evidence.
3. Match on provider reference first; use business ID, amount, product and time as secondary checks.
4. Treat duplicate IDs idempotently. Never silently overwrite an event; use append-only correction/reversal events.
5. Classify at minimum: `MATCHED`, `PENDING_PROVIDER`, `MISMATCH`, `PROVIDER_ONLY`, `KASH_ONLY`, `REVERSED`, `DISPUTED`.
6. Calculate commissions only from the provider agreement's eligible event definition and effective date. Show estimated and confirmed amounts separately.
7. Export a period report with counts, totals, commission basis, discrepancies, evidence references, and a generation timestamp.
8. Minimize customer data; never collect customer PINs or network credentials. Keep only fields required by the provider agreement and reconciliation purpose.

## Authorization lifecycle
`PENDING` → `ACTIVE` only after provider approval is independently verified; provider withdrawal/expiry moves it to `SUSPENDED` or `INACTIVE`. KMCC operators cannot mark an authorization active without evidence/audit event. Auditor checks authorization with the server before enabling the sales feature.

## Acceptance tests before production
- Unapproved, expired, suspended, or revoked merchants cannot submit commissionable sales.
- A local Auditor record alone never becomes provider-confirmed.
- Repeated upload of the same transaction does not duplicate totals.
- Provider-only and KASH-only events appear as discrepancies.
- Reversals reduce eligible commission according to the agreement and remain in history.
- Users cannot view other businesses' data unless their role explicitly permits it.
- Existing business registration, subscription status, Auditor sync and KMCC sync tests continue to pass.
- Exported reports reproduce totals from the stored reconciliation records.


## Attendant voucher handling
- The attendant sales screen offers a choice to include provider-issued voucher details on the receipt, where the receipt renderer/provider contract supports it, or print a separate voucher.
- Voucher number/PIN must be returned by the approved provider after a confirmed successful fulfillment. Never generate, guess, or display a redeemable code locally.
- Do not expose voucher details for `PENDING`, `FAILED`, `REVERSED`, or unconfirmed transactions.
- Treat voucher PINs as sensitive: restrict visibility to the authorized attendant/admin involved in the sale, avoid logging the PIN in ordinary application logs, and avoid retaining it longer than required by the provider and applicable policy.
- The current UI implements the option and separate-print preview flow, but the current `/api/airtime` endpoint only records a request as `Provider Not Connected`. Provider fulfillment, secure voucher return, and receipt composition are **not live**. The UI must not be considered production-ready until the provider adapter returns a verified success status and the receipt path consumes the selected option.


## Prepaid electricity workflow
- The attendant selects the approved electricity provider/distributor, enters the prepaid meter number and purchase value, selects the merchant's customer payment method, and submits.
- Only the provider's verified successful response may return a redeemable electricity token. Never generate a token locally.
- Offer separate token printing and inclusion on the receipt, subject to the provider's response and receipt renderer support.
- Retain provider transaction reference, business ID, attendant, amount, meter number (access-controlled), status, timestamp and reconciliation result.
- Current endpoint records a `Provider Not Connected` purchase intent only. It does not buy electricity or issue a token. A provider adapter, idempotency, pending-result polling/webhooks, reversal handling and secure token access must be implemented before production.
