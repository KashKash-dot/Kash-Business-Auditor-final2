# Kash Business Auditor — 2026-10-03 Update

## Integrated now
- Sales page has a direct **Airtime Sales** link.
- Dedicated Airtime Sales page is part of the app navigation and is available to Admin and Attendant modes.
- Airtime page captures network/provider, customer cellphone number, amount and payment method.
- Airtime provider/enable controls are present in Admin settings.
- Airtime remains disabled until an approved provider/API is connected; the UI is prepared so a future update can activate delivery without redesigning the app.
- Airtime transaction-intent endpoint and storage are included.
- Live app network status is shown using Capacitor Network.
- Existing card-present payment architecture remains in place for provider SDK/Bluetooth/Wi-Fi/LAN/USB terminal integrations.

## Card terminal rule
The app is prepared to receive an approved terminal/provider transaction result and reference. A generic Bluetooth/Wi-Fi connection alone cannot legally or technically process bank cards; the selected terminal provider must expose an SDK/API/integration protocol. The Auditor does not store card PAN, PIN or CVV.

## Build note
The source was updated and TypeScript syntax was checked. A full Vite production build could not be executed in this environment because npm dependencies were not available locally and dependency installation timed out. The project package.json already declares the required Capacitor Network and Bluetooth LE dependencies.

## v4 Security & Navigation Update — 2026-10-03
- Added a demo Admin PIN/password of `123456` for a fresh Admin setup.
- Admin setup screen pre-fills the demo PIN and clearly tells the Admin to change it.
- Admin login now labels the credential as Admin PIN/password.
- Existing Admin Security password-change flow remains the reset mechanism; the Admin can replace `123456` with a new credential.
- Converted the Sales → Airtime quick link into an accessible button so it reliably opens the built-in Airtime page.
- Internal navigation controls continue to open Dashboard, Sales, Airtime, Employees, Attendance, Stock, Expenses, Reports, Receipts, Subscription and Admin views.

## v5 — Empty-page navigation behavior
- All Admin navigation sections remain clickable even when their datasets are empty.
- Added a consistent white empty-state popup reading “No data available yet”.
- Employees, Attendance, Stock, Expenses, Reports and Receipts now show a useful empty state instead of a blank/unfinished area.
- Forms remain available where appropriate so the first record can be entered immediately.
- Reports and Receipts open as active pages and show the empty popup until source data exists.


## v9 pre-APK packaging update — 2026-10-03
- Added universal in-app **Go Back** navigation with page history.
- Added barcode field and camera scanning control on Sales.
- Added Admin Stock barcode / price-tag registration and selling price.
- Added backend barcode lookup so a registered barcode can identify the item/code/name/price during a sale.
- Added Android CAMERA permission required for camera barcode scanning.
- Receipt printing remains available through the existing Print Receipts action and print stylesheet; physical Bluetooth/Wi-Fi printer validation remains device/provider dependent.
- APK build was not falsely marked complete: the local environment did not have installed npm dependencies and `npm install` timed out, so native compilation still requires dependency installation/build execution in a suitable Android/Node build environment.
