# Kash Business Auditor — Live Deployment Update

Live AppDeploy application:
- App ID: kash-business-auditor-b6wj6y
- Live URL: https://kash-business-auditor-b6wj6y.v2.appdeploy.ai/
- Latest live snapshot: 1791024169535 (barcode update) and 1791024169535/Go Back source applied in the latest deployment flow.

## Latest user-requested changes
1. Admin Item / Service Codes support barcode registration.
2. Admin registers barcode together with product/service name, selling price, cost, VAT/tax, commission and stock-tracking setting.
3. Attendant can scan/enter the barcode and the App identifies the registered product/service and Admin-configured price.
4. Unknown barcode/code is rejected with a contact-Admin message.
5. Multiple scanned/entered items can be combined into one receipt.
6. A Go Back button is now shown in the main page header for in-app navigation. It returns to the immediately previous tab or Admin section and is disabled when there is no previous in-app page.
7. Go Back navigation is covered by the current QA test suite.

## Deployment verification
The latest deployment completed successfully with no frontend, network, or backend errors.

## Important backup note
This ZIP preserves the previously packaged source baseline and adds this live deployment update manifest. The AppDeploy remote source snapshot is the production source of truth for the newest live changes.
