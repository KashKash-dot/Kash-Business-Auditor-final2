# Kash Business Auditor — Installation Icon

The exact logo supplied by the project owner on 2026-10-03 is stored as:

- `public/resources/installation-icon.png` — PWA/browser installation icon
- `android-template/app/src/main/res/drawable/kash_business_auditor_icon.png` — native Android icon source

The web app manifest and `index.html` point to the supplied installation icon. The same visual asset is preserved for the future APK/installer packaging.
