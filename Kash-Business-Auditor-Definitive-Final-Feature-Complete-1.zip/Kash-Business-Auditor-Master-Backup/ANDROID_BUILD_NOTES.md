# Kash Business Auditor — Android Packaging Notes

This project is a Vite/React application with an Android packaging scaffold intended for Capacitor.

## Capabilities prepared
- Internet-only backend communication.
- Wi-Fi/network capability for backend access, network printers and future supported peripherals.
- Bluetooth capability for Bluetooth receipt printers and future supported peripherals/card-terminal SDKs.
- Card-present payment fields and provider/terminal configuration.
- White data-entry and printable report/receipt pages.
- Black/gold application shell.

## Packaging
1. Install Node.js and Android Studio/Android SDK.
2. Run `npm install`.
3. Run `npx cap add android` once to create the native Android project.
4. Apply the permissions in `android-template/app/src/main/AndroidManifest.xml` to the generated Android manifest (or merge them through the Android project).
5. Put the approved official Kash Business Auditor logo into the Android mipmap resources before the release build.
6. Run `npm run android:build` to produce the debug APK, after the Android project has been created.

The native terminal/payment integration remains provider-specific; Wi-Fi/Bluetooth permissions do not by themselves implement a bank terminal protocol.
