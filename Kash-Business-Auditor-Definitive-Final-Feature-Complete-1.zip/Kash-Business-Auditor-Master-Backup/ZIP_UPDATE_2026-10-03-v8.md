# ZIP Update v8 — Exact Installation Icon

Added the exact Kash Business Auditor gold-and-black K open-book logo supplied by the owner.

Included:
- PWA/browser installation icon
- Web manifest and favicon references
- Apple touch icon reference
- Native Android drawable copy for future APK packaging
- Installation icon documentation

Source of truth for the live web installation configuration remains the current AppDeploy deployment.
