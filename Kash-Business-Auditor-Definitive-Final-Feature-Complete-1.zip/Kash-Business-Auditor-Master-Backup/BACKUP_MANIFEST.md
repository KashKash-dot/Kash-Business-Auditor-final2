# Kash Business Auditor Master Backup

Created from the verified AppDeploy source snapshot.

App:
- Name: Kash Business Auditor
- App ID: kash-business-auditor-b6wj6y
- Working URL: https://kash-business-auditor-b6wj6y.v2.appdeploy.ai/
- Source snapshot: 1790949995703

Included:
- React/Vite frontend
- Backend API
- Authentication configuration
- Realtime helper files
- Tests
- Build configuration
- Prepared Master Control Centre integration plan

Deployment state:
- Last working Auditor deployment remains the source of truth.
- The later MCC integration attempt was NOT deployed because the daily AppDeploy deployment-credit limit was reached.
- Do not create a duplicate Auditor project.

Next resume step:
- After deployment credits reset, re-read the latest AppDeploy source snapshot before applying the MCC integration changes, then deploy to the SAME app ID.


## 2026-10-03 update
- Added Capacitor Android packaging configuration and build scripts.
- Added Android Wi-Fi/network and Bluetooth permission template for future printers/peripherals/terminal SDKs.
- Added Android packaging notes and branding requirements.
- Fixed persistence of card-terminal provider, connection type and terminal ID in Admin settings.
- Master Control Centre remains a separate application; no MCC UI has been embedded in the Auditor.

## 2026-10-03 Airtime + Connectivity update
- Added a built-in Airtime Sales page and a direct link from the Sales page.
- Added Airtime provider/enable controls in Admin settings; the module remains disabled until an approved provider/API is configured.
- Added Airtime transaction-intent storage endpoint for future provider activation.
- Added live app network status display using Capacitor Network.
- Retained card-present provider adapter architecture for Bluetooth/Wi-Fi/LAN/SDK terminal integrations; the app does not store card PAN, PIN or CVV.

## Latest update
- v4: Demo Admin PIN/password `123456` on fresh setup; reset available in Admin Security.
- Sales → Airtime navigation is an explicit accessible button.
