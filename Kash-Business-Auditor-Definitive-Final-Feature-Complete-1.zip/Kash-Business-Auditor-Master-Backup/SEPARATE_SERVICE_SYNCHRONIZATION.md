# Separate Service Synchronization

Kash Business Auditor does not expose the separate control application as a page, menu or user-facing module.

The Auditor can exchange business authorization/subscription state with a separately deployed service through backend environment configuration:
- KASH_SERVICE_SYNC_URL
- KASH_SERVICE_SYNC_KEY

No demo service key is stored in the application source.
