# Branding

Use the approved original Kash Business Auditor gold-and-black open-book `K` logo for:
- Android launcher/app icon
- Opening/login screen
- Main app header/brand mark
- Consistent page branding
- Printed receipt/report header where appropriate

Do not redesign or substitute the approved logo.

The original logo asset is intentionally not fabricated in this source update. Add the approved source image/vector to the Android mipmap resources before the release build.
