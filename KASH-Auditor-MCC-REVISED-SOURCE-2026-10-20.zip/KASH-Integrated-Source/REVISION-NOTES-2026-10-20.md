# KASH Integrated Source Revision Notes — 2026-10-20

This package combines the latest Auditor/KMCC source with the requested UI and sale-correction changes.

## Included source changes
- Larger, more readable fonts and larger controls in Auditor and KMCC Windows UI.
- White data-entry fields with dark text, including text inputs, dropdowns, textareas, and placeholders.
- Auditor authorized sale correction dialog supports editing item/service code, name, quantity, unit price, discount, payment method, payment status/reference, and reason.
- Auditor backend route `POST /api/sales/correct` verifies the Admin password, validates edits, recalculates VAT and total, saves corrected values, and writes a `saleCorrections` audit record with original/corrected snapshots.
- Stock-linked sales reduce stock quantity and save the stock unit cost on the sale; insufficient stock blocks the sale.
- Correcting a stock-linked sale attempts to reverse the original stock movement and apply the corrected code/quantity.
- Admin section includes an Item Code Management entry point to Stock.
- Reports include weekly and monthly sales, cost of goods sold, expenses, and net-profit summaries. Older sales without saved unit costs cannot be retroactively costed.

## Verification status
- KMCC JavaScript syntax checks pass (`npm test`).
- Full Auditor build/type-check was not completed in this environment because project dependencies (React, Capacitor, AppDeploy client, Lucide React and related types) are not installed. Install dependencies in the normal build environment and run the project's build before replacing any working installation.
- The stock/sale update operations use the available database API and are not a single atomic database transaction. Test with sample data and a backup before production use.
