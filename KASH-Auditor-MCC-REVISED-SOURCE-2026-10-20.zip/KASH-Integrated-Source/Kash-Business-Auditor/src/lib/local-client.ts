/*
 * Standalone desktop adapter. This keeps the UI independent of AppDeploy's
 * injected client. Records are stored in the current Windows user profile via
 * Chromium localStorage. This is a local-first bridge, not a substitute for a
 * hardened shared KMCC service; see STANDALONE_ARCHITECTURE.md.
 */
type RecordValue = Record<string, any>;
type Response = { data: any; status: number };
const DB_KEY = 'kba.standalone.db.v1';
const AUTH_KEY = 'kba.standalone.identity.v1';
const id = () => (globalThis.crypto?.randomUUID?.() || `kba-${Date.now()}-${Math.random().toString(16).slice(2)}`);
const load = (): Record<string, any> => { try { return JSON.parse(localStorage.getItem(DB_KEY) || '{}'); } catch { return {}; } };
let restoreChecked = false;
let restoringSnapshot = false;
const backendConfig = async () => await window.kashDesktop?.getBackendConfig().catch(() => ({endpoint:'',apiKey:''})) || {endpoint:'',apiKey:''};
const restoreSnapshotOnce = async () => {
  if (restoreChecked) return;
  restoreChecked = true;
  const existingRaw = localStorage.getItem(DB_KEY);
  if (existingRaw) {
    try { const existing = JSON.parse(existingRaw); if (existing && (existing.settings?.businessName || existing.sales?.length || existing.employees?.length || existing.stock?.length || existing.expenses?.length)) return; } catch {}
  }
  const cfg = await backendConfig();
  if (!cfg.endpoint || !cfg.apiKey) return;
  try {
    const response = await fetch(cfg.endpoint + '/api/auditor-data', {headers:{authorization:'Bearer '+cfg.apiKey},cache:'no-store'});
    if (!response.ok) return;
    const result = await response.json();
    const snapshots = Array.isArray(result.items) ? result.items : [];
    // This standalone Auditor installation is for one business. Never guess if the server has multiple snapshots.
    if (snapshots.length === 1 && snapshots[0]?.payload && typeof snapshots[0].payload === 'object') {
      restoringSnapshot = true;
      localStorage.setItem(DB_KEY, JSON.stringify(snapshots[0].payload));
      restoringSnapshot = false;
    }
  } catch { /* Keep local operation available when the shared backend is offline. */ }
};
const save = (db: Record<string, any>) => {
  localStorage.setItem(DB_KEY, JSON.stringify(db));
  if (restoringSnapshot) return;
  // Local write happens first. The shared SQLite snapshot is an additional durable backup.
  void backendConfig().then(cfg => {
    const businessId = String(db.settings?.businessId || '');
    if (!cfg.endpoint || !cfg.apiKey || businessId.length < 3 || !String(db.settings?.businessName || '').trim()) return;
    return fetch(cfg.endpoint + '/api/auditor-data/' + encodeURIComponent(businessId), {
      method:'PUT', headers:{'content-type':'application/json','authorization':'Bearer '+cfg.apiKey,'x-kash-source':'auditor'},
      body:JSON.stringify({payload:db}), keepalive:true
    });
  }).catch(() => {});
};
const settingsDefaults = () => ({currency:'ZAR',vatRate:15,businessName:'',address:'',phone:'',email:'',businessId:`KBA-${id().slice(-8).toUpperCase()}`,adminName:'',adminIdType:'ID Number',adminIdNumber:'',adminPhone:'',adminEmail:'',trialStart:new Date().toISOString(),trialDays:32,status:'TRIAL',subscriptionPlan:'Monthly',subscriptionPaymentMethod:'EFT',subscriptionPaymentReference:'',subscriptionAmount:0,bankAccounts:[],cardTerminalProvider:'',cardTerminalConnection:'Provider SDK',cardTerminalId:'',airtimeProvider:'',airtimeEnabled:false});
const ensure = (db: Record<string, any>) => { db.settings ||= settingsDefaults(); db.employees ||= []; db.sales ||= []; db.stock ||= []; db.expenses ||= []; db.airtime ||= []; db.itemCodes ||= []; db.admin ||= null; return db; };
const digest = async (value: string) => { const bytes = new TextEncoder().encode(value); const hash = await crypto.subtle.digest('SHA-256', bytes); return [...new Uint8Array(hash)].map(x=>x.toString(16).padStart(2,'0')).join(''); };
const ok = (data: any, status = 200): Response => ({data,status});
const fail = (message: string, status = 400): never => { const e: any = new Error(message); e.response = {data:{error:message},status}; throw e; };
const authenticated = () => { try { return JSON.parse(localStorage.getItem(AUTH_KEY) || 'null'); } catch { return null; } };
const activeRole = () => authenticated()?.role || '';
const needAdmin = () => { if (activeRole() !== 'admin') fail('Admin authorization required.',403); };
const itemsResponse = (items: any[]) => ok({items});
const route = async (method: string, rawUrl: string, body: RecordValue = {}): Promise<Response> => {
 await restoreSnapshotOnce();
 const url = new URL(rawUrl, 'http://kash.local'); const path = url.pathname; const db = ensure(load());
 if (method === 'GET' && path === '/api/_healthcheck') return ok({message:'Success',mode:'standalone-local'});
 if (method === 'GET' && path === '/api/me') return ok({userId:'local-windows-user',name:db.settings.adminName || 'Business Admin',email:db.settings.adminEmail || ''});
 if (method === 'GET' && path === '/api/access/status') return ok({setupRequired:!db.admin,needsPassword:!db.admin,needsAttendant:db.employees.length===0,attendantCount:db.employees.length,adminConfigured:Boolean(db.admin)});
 if (method === 'POST' && path === '/api/admin/setup') {
   if(db.admin) fail('Admin setup is already complete.',409);
   const password=String(body.password||''); if(password.length<6) fail('Admin password must be at least 6 characters.');
   const name=String(body.attendantName||'').trim(), pin=String(body.attendantPin||'').trim();
   if(!db.employees.length && (!name || !/^\d{4,6}$/.test(pin))) fail('Enter an attendant name and a 4 to 6 digit PIN.');
   db.admin={passwordHash:await digest(password)};
   if(!db.employees.length) db.employees.push({id:id(),name,commission:0,clockIn:null,clockOut:null,pinHash:await digest(pin),pinConfigured:true});
   save(db); return ok({configured:true});
 }
 if (method === 'POST' && path === '/api/admin/login') { if(!db.admin || db.admin.passwordHash!==await digest(String(body.password||''))) fail('Incorrect Admin password.',401); localStorage.setItem(AUTH_KEY,JSON.stringify({role:'admin',token:id()})); return ok({authorized:true,adminSessionToken:id()}); }
 if (method === 'POST' && path === '/api/attendant/login') { const emp=db.employees.find((x:any)=>x.id===String(body.employeeId||'')); if(!emp || emp.pinHash!==await digest(String(body.pin||''))) fail('Incorrect attendant PIN.',401); localStorage.setItem(AUTH_KEY,JSON.stringify({role:'attendant',employeeId:emp.id,token:id()})); return ok({authorized:true,attendantSessionToken:id(),attendant:{id:emp.id,name:emp.name}}); }
 if (method === 'GET' && path === '/api/employees') return itemsResponse(db.employees.map(({pinHash,...e}:any)=>({...e,pinConfigured:Boolean(pinHash)})));
 if (method === 'GET' && path === '/api/settings') return ok({...db.settings});
 if (method === 'PUT' && path === '/api/settings') { needAdmin(); const {adminSessionToken,...safe}=body; db.settings={...db.settings,...safe}; save(db); return ok({saved:true}); }
 if (method === 'POST' && path === '/api/admin/password/change') { needAdmin(); if(db.admin?.passwordHash!==await digest(String(body.currentPassword||''))) fail('Current Admin password is incorrect.',403); const p=String(body.newPassword||''); if(p.length<6) fail('New Admin password must be at least 6 characters.'); db.admin.passwordHash=await digest(p); save(db); return ok({changed:true}); }
 if (method === 'POST' && path === '/api/admin/attendants') { needAdmin(); const name=String(body.name||'').trim(), pin=String(body.pin||''); if(!name) fail('Attendant name is required.'); if(!/^\d{4,6}$/.test(pin)) fail('Attendant PIN must be 4 to 6 digits.'); const employee={id:id(),name,commission:Number(body.commission)||0,clockIn:null,clockOut:null,pinHash:await digest(pin),pinConfigured:true}; db.employees.push(employee); save(db); return ok({id:employee.id},201); }
 if (method === 'POST' && path === '/api/admin/attendants/pin') { needAdmin(); const emp=db.employees.find((x:any)=>x.id===String(body.employeeId)); if(!emp) fail('Attendant not found.',404); const pin=String(body.pin||''); if(!/^\d{4,6}$/.test(pin)) fail('Attendant PIN must be 4 to 6 digits.'); emp.pinHash=await digest(pin); save(db); return ok({saved:true}); }
 if (method === 'GET' && path === '/api/sales') return itemsResponse(db.sales);
 if (method === 'POST' && path === '/api/sales') { if(!activeRole()) fail('Please sign in first.',403); const sale: RecordValue={...body,id:id(),voided:false}; delete sale.adminSessionToken; delete sale.attendantSessionToken; if(activeRole()==='attendant') sale.attendant=db.employees.find((x:any)=>x.id===authenticated()?.employeeId)?.name||sale.attendant; db.sales.push(sale); save(db); return ok({id:sale.id},201); }
 if (method === 'POST' && path === '/api/sales/void') { needAdmin(); if(db.admin?.passwordHash!==await digest(String(body.password||''))) fail('Admin authorization failed.',403); const sale=db.sales.find((x:any)=>x.id===String(body.saleId)); if(!sale) fail('Sale not found.',404); sale.voided=true; sale.voidedAt=new Date().toISOString(); sale.voidReason=String(body.reason||'Authorized correction'); save(db); return ok({voided:true}); }
 if (method === 'POST' && path === '/api/sales/correct') { if(db.admin?.passwordHash!==await digest(String(body.password||''))) fail('Admin authorization failed. Enter the correct Admin password.',403); const sale=db.sales.find((x:any)=>x.id===String(body.saleId)); if(!sale) fail('Sale not found.',404); if(sale.voided) fail('A voided sale cannot be edited.',409); const changes=body.changes&&typeof body.changes==='object'?body.changes:{}; const allowed=['code','service','qty','price','discount','payment','paymentStatus','paymentReference','total','correctionReason','correctedAt']; sale.correctionHistory ||= []; sale.correctionHistory.push({at:new Date().toISOString(),by:activeRole(),reason:String(body.reason||'Authorized correction'),before:{code:sale.code,service:sale.service,qty:sale.qty,price:sale.price,discount:sale.discount,payment:sale.payment,paymentStatus:sale.paymentStatus,paymentReference:sale.paymentReference,total:sale.total}}); for(const key of allowed) if(Object.prototype.hasOwnProperty.call(changes,key)&&key!=='total') sale[key]=changes[key]; const correctedSubtotal=Math.max(0,Number(sale.qty||0)*Number(sale.price||0)-Number(sale.discount||0)); sale.vat=correctedSubtotal*(Number(db.settings.vatRate)||0)/100; sale.total=correctedSubtotal+sale.vat; sale.correctedAt=new Date().toISOString(); sale.correctionReason=String(body.reason||'Authorized correction'); save(db); return ok({corrected:true,sale}); }
 if (method === 'GET' && path === '/api/stock') return itemsResponse(db.stock);
 if (method === 'GET' && path === '/api/stock/lookup') { const item=db.stock.find((x:any)=>String(x.barcode||'').trim()===String(url.searchParams.get('barcode')||'').trim()); return ok({item:item||null}); }
 if (method === 'POST' && path === '/api/stock') { needAdmin(); const item: RecordValue={...body,id:id()}; delete item.adminSessionToken; db.stock.push(item); save(db); return ok({id:item.id},201); }
 if (method === 'GET' && path === '/api/expenses') return itemsResponse(db.expenses);
 if (method === 'POST' && path === '/api/expenses') { needAdmin(); const item: RecordValue={...body,id:id()}; delete item.adminSessionToken; db.expenses.push(item); save(db); return ok({id:item.id},201); }
 if (method === 'GET' && path === '/api/item-codes') return itemsResponse([...db.itemCodes,...db.stock.map((x:any)=>({id:x.id,code:x.code,barcode:x.barcode,name:x.name,price:x.price,active:true}))]);
 if (method === 'POST' && path === '/api/airtime') { if(!activeRole()) fail('Please sign in first.',403); const item: RecordValue={...body,id:id(),status:'Provider Not Connected'}; delete item.adminSessionToken; delete item.attendantSessionToken; db.airtime.push(item); save(db); return ok({id:item.id},201); }
 if (method === 'GET' && path === '/api/airtime') return itemsResponse(db.airtime);
 if (method === 'POST' && path === '/api/attendance') { if(!activeRole()) fail('Please sign in first.',403); const employeeId=activeRole()==='attendant'?authenticated()?.employeeId:String(body.employeeId||''); const emp=db.employees.find((x:any)=>x.id===employeeId); if(!emp) fail('Employee not found.',404); const now=new Date().toISOString(); if(emp.clockIn&&!emp.clockOut) emp.clockOut=now; else {emp.clockIn=now;emp.clockOut=null;} save(db); return ok({saved:true}); }
 if (method === 'POST' && path === '/api/service-sync/push') {
   const cfg = await window.kashDesktop?.getBackendConfig().catch(() => ({endpoint:'',apiKey:''}));
   if (!cfg?.endpoint || !cfg?.apiKey) return ok({state:'NOT_CONFIGURED',message:'Shared backend is not configured. Set kash-backend.json in the app data folder.'});
   const payload = {
     businessId: String(db.settings.businessId || ''),
     id: String(db.settings.businessId || ''),
     businessName: String(db.settings.businessName || ''),
     name: String(db.settings.businessName || ''),
     address: String(db.settings.address || ''),
     phone: String(db.settings.phone || ''),
     email: String(db.settings.email || ''),
     ownerName: String(db.settings.adminName || ''),
     ownerIdType: String(db.settings.adminIdType || ''),
     ownerIdNumber: String(db.settings.adminIdNumber || ''),
     status: String(db.settings.status || 'TRIAL').toUpperCase(),
     subscriptionPlan: String(db.settings.subscriptionPlan || 'Monthly'),
     subscriptionPaymentMethod: String(db.settings.subscriptionPaymentMethod || 'EFT'),
     subscriptionPaymentReference: String(db.settings.subscriptionPaymentReference || ''),
     subscriptionAmount: Number(db.settings.subscriptionAmount || 0),
     trialStart: String(db.settings.trialStart || new Date().toISOString()),
     trialDays: Number(db.settings.trialDays || 32),
     sourceApp: 'Kash Business Auditor',
     updatedAt: new Date().toISOString()
   };
   if (!payload.businessId || !payload.businessName) return ok({state:'FAILED',message:'Register the business name and Business ID before synchronizing.'});
   try {
     const response = await fetch(cfg.endpoint + '/api/businesses', {
       method:'POST',
       headers:{'content-type':'application/json','authorization':'Bearer '+cfg.apiKey,'x-kash-source':'auditor'},
       body:JSON.stringify(payload)
     });
     const data = await response.json().catch(()=>({}));
     if (!response.ok) return ok({state:'FAILED',message:String(data.error || `Backend rejected synchronization (${response.status}).`)});
     db.syncState={state:'SYNCED',lastSyncAt:new Date().toISOString(),businessId:payload.businessId};
     save(db);
     return ok({state:'SYNCED',lastSyncAt:db.syncState.lastSyncAt,message:'Business profile synchronized with the KASH shared backend.'});
   } catch (error) {
     return ok({state:'FAILED',message:error instanceof Error?error.message:'Shared backend could not be reached.'});
   }
 }
 if (method === 'GET' && path === '/api/service-sync/status') {
   const cfg = await window.kashDesktop?.getBackendConfig().catch(() => ({endpoint:'',apiKey:''}));
   return ok(cfg?.endpoint && cfg?.apiKey ? {configured:true,state:db.syncState?.state || 'PENDING',lastSyncAt:db.syncState?.lastSyncAt || null} : {configured:false,state:'NOT_CONFIGURED',message:'Shared backend connection details are missing.'});
 }
 return fail(`Unsupported local operation: ${method} ${path}`,404);
};
export const api = {
 get: async (url:string) => route('GET',url),
 post: async (url:string, body:RecordValue={}) => route('POST',url,body),
 put: async (url:string, body:RecordValue={}) => route('PUT',url,body),
 delete: async (url:string) => route('DELETE',url),
};
export const auth = {
 isSignedIn: () => true,
 signIn: async () => ({user:{userId:'local-windows-user',name:'Local Business User'}}),
 signOut: async () => { localStorage.removeItem(AUTH_KEY); return true; },
};
